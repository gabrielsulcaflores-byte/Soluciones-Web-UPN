$MavenArgs = $args
$ErrorActionPreference = 'Stop'
$projectRoot = $PSScriptRoot
$installedMaven = Get-Command mvn.cmd -ErrorAction SilentlyContinue
if ($installedMaven) { & $installedMaven.Source @MavenArgs; exit $LASTEXITCODE }
$version = '3.9.9'
$toolsDir = Join-Path $projectRoot '.runtime\tools'
$mavenExe = Join-Path $toolsDir "apache-maven-$version\bin\mvn.cmd"
if (-not (Test-Path -LiteralPath $mavenExe)) {
    New-Item -ItemType Directory -Force $toolsDir | Out-Null
    $archive = Join-Path $toolsDir 'maven.zip'
    $url = "https://repo.maven.apache.org/maven2/org/apache/maven/apache-maven/$version/apache-maven-$version-bin.zip"
    Write-Host 'Descargando Maven desde Maven Central...'
    Invoke-WebRequest -Uri $url -OutFile $archive
    $checksumFile = Join-Path $toolsDir 'maven.zip.sha512'
    Invoke-WebRequest -Uri "$url.sha512" -OutFile $checksumFile
    $expected = ((Get-Content -LiteralPath $checksumFile -Raw).Trim() -split '\s+')[0]
    $hashAlgorithm = [System.Security.Cryptography.SHA512]::Create()
    $archiveStream = [System.IO.File]::OpenRead($archive)
    try { $actual = [System.BitConverter]::ToString($hashAlgorithm.ComputeHash($archiveStream)).Replace('-', '') }
    finally { $archiveStream.Dispose(); $hashAlgorithm.Dispose() }
    if ($actual -ne $expected) { throw 'La verificación SHA512 de Maven falló.' }
    Add-Type -AssemblyName System.IO.Compression.FileSystem
    [System.IO.Compression.ZipFile]::ExtractToDirectory($archive, $toolsDir)
}
& $mavenExe @MavenArgs
exit $LASTEXITCODE
