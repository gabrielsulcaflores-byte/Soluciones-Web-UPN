package pe.edu.solucionesweb.tramite;

import static org.junit.jupiter.api.Assertions.*;

import java.util.Map;
import org.junit.jupiter.api.Test;
import pe.edu.solucionesweb.tramite.controller.ReporteServlet;
import pe.edu.solucionesweb.tramite.model.Usuario;
import pe.edu.solucionesweb.tramite.service.*;
import pe.edu.solucionesweb.tramite.util.*;

class DomainTest {
  @Test
  void passwordRoundTripAndSalts() {
    String a = Password.hash("Password!2026"), b = Password.hash("Password!2026");
    assertNotEquals(a, b);
    assertTrue(Password.verify("Password!2026", a));
    assertFalse(Password.verify("incorrecta", a));
    assertFalse(Password.verify("x", "malformado"));
  }

  @Test
  void validatesIdentity() {
    assertEquals("12345678", Validation.dni("12345678"));
    assertThrows(IllegalArgumentException.class, () -> Validation.dni("123"));
    assertThrows(IllegalArgumentException.class, () -> Validation.identification("123456789"));
    assertThrows(IllegalArgumentException.class, () -> Validation.email("correo-mal"));
    assertEquals("persona@correo.pe", Validation.email("Persona@Correo.pe"));
  }

  @Test
  void stateMachine() {
    TramiteService.transition("PENDIENTE", "EN_PROCESO");
    TramiteService.transition("DERIVADO", "EN_PROCESO");
    TramiteService.transition("EN_PROCESO", "ATENDIDO");
    TramiteService.transition("ATENDIDO", "CONCLUIDO");
    assertThrows(
        IllegalArgumentException.class, () -> TramiteService.transition("PENDIENTE", "CONCLUIDO"));
    assertThrows(
        IllegalArgumentException.class, () -> TramiteService.transition("CONCLUIDO", "PENDIENTE"));
    assertThrows(
        IllegalArgumentException.class, () -> TramiteService.transition("EN_PROCESO", "DERIVADO"));
  }

  @Test
  void ownershipPermissions() {
    Usuario citizen = new Usuario();
    citizen.setId(7L);
    citizen.setRol("CIUDADANO");
    Access.tramite(citizen, Map.of("ciudadano_id", 7L, "area_id", 2L));
    assertThrows(
        SecurityException.class,
        () -> Access.tramite(citizen, Map.of("ciudadano_id", 8L, "area_id", 2L)));
    assertThrows(SecurityException.class, () -> Access.staff(citizen));
    Usuario staff = new Usuario();
    staff.setId(3L);
    staff.setRol("FUNCIONARIO");
    staff.setAreaId(2L);
    Access.tramite(staff, Map.of("area_id", 2L));
    assertThrows(SecurityException.class, () -> Access.tramite(staff, Map.of("area_id", 4L)));
  }

  @Test
  void preventsFormulaInjectionAndQuotes() {
    assertEquals("\"'=1+1\"", ReporteServlet.csv("=1+1"));
    assertEquals("\"'=1+1\n\"", ReporteServlet.csv("=1+1\n"));
    assertEquals("\"a\"\"b\"", ReporteServlet.csv("a\"b"));
    assertEquals("\"texto\"", ReporteServlet.csv("texto"));
  }
}
