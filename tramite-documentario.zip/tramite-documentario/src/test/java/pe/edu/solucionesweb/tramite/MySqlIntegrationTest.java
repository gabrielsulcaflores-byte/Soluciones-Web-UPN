package pe.edu.solucionesweb.tramite;

import static org.junit.jupiter.api.Assertions.*;

import java.sql.*;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.condition.EnabledIfEnvironmentVariable;
import pe.edu.solucionesweb.tramite.dao.*;
import pe.edu.solucionesweb.tramite.model.*;
import pe.edu.solucionesweb.tramite.service.*;
import pe.edu.solucionesweb.tramite.util.*;

/** Ejecutar únicamente con base desechable y datos_demo.sql importado. */
@EnabledIfEnvironmentVariable(named = "RUN_MYSQL_TESTS", matches = "true")
class MySqlIntegrationTest {
  @Test
  void rollbackIfHistoryFails() throws Exception {
    Usuario admin = new UsuarioDAO().obtener(1);
    TramiteDAO dao = new TramiteDAO();
    long before;
    try (Connection c = Database.open()) {
      before = Sql.number(Sql.one(c, "SELECT COUNT(*) n FROM tramites").get("n"));
    }
    EventRepository failing =
        (c, t, u, a, d) -> {
          throw new SQLException("Fallo inyectado en historial");
        };
    TramiteService service = new TramiteService(Database::open, dao, failing, new DerivacionDAO());
    Tramite t = new Tramite();
    t.setTipoId(1L);
    t.setSolicitante("Prueba rollback");
    t.setIdentificacion("10000003");
    t.setCiudadanoId(3L);
    t.setAsunto("Transacción");
    t.setDescripcion("Prueba");
    t.setAreaId(1L);
    t.setEstado("PENDIENTE");
    assertThrows(SQLException.class, () -> service.guardar(admin, t));
    try (Connection c = Database.open()) {
      assertEquals(before, Sql.number(Sql.one(c, "SELECT COUNT(*) n FROM tramites").get("n")));
    }
  }

  @Test
  void rollbackDerivationOnEventFailure() throws Exception {
    Usuario admin = new UsuarioDAO().obtener(1);
    long id;
    try (Connection c = Database.open()) {
      id =
          Sql.insert(
              c,
              "INSERT INTO"
                  + " tramites(codigo,tipo_id,solicitante,identificacion,asunto,descripcion,area_id,usuario_id)"
                  + " VALUES(?,1,'Rollback','10000003','Prueba','Prueba',1,1)",
              TramiteService.code("TRA"));
    }
    EventRepository failing =
        (c, t, u, a, d) -> {
          throw new SQLException("Fallo inyectado");
        };
    TramiteService service =
        new TramiteService(Database::open, new TramiteDAO(), failing, new DerivacionDAO());
    assertThrows(SQLException.class, () -> service.derivar(admin, id, 2, "Motivo de prueba", 0));
    try (Connection c = Database.open()) {
      var t = Sql.one(c, "SELECT * FROM tramites WHERE id=?", id);
      assertEquals(1, Sql.number(t.get("area_id")));
      assertEquals("PENDIENTE", t.get("estado"));
      assertEquals(
          0,
          Sql.number(
              Sql.one(c, "SELECT COUNT(*) n FROM derivaciones WHERE tramite_id=?", id).get("n")));
    }
  }

  @Test
  void rejectsForeignKeyAndUniqueViolations() throws Exception {
    try (Connection c = Database.open()) {
      assertThrows(
          SQLException.class,
          () ->
              Sql.update(
                  c, "INSERT INTO areas(nombre,descripcion) VALUES('Mesa de Partes','Duplicado')"));
      assertThrows(
          SQLException.class,
          () ->
              Sql.update(
                  c,
                  "INSERT INTO"
                      + " tramites(codigo,tipo_id,solicitante,identificacion,asunto,descripcion,area_id,usuario_id)"
                      + " VALUES('TRA-INVALID',999999,'Inválido','10000003','Prueba','Prueba',1,1)"));
    }
  }
}
