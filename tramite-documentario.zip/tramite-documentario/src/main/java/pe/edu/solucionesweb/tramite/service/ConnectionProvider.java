package pe.edu.solucionesweb.tramite.service;

import java.sql.*;

@FunctionalInterface
public interface ConnectionProvider {
  Connection open() throws SQLException;
}
