package pe.edu.solucionesweb.tramite.service;

import java.sql.*;
import java.util.*;
import pe.edu.solucionesweb.tramite.dao.*;
import pe.edu.solucionesweb.tramite.model.*;
import pe.edu.solucionesweb.tramite.util.*;

/** Cada escritura del expediente y su historial comparte una única transacción. */
public class TramiteService {
  private final ConnectionProvider connections;
  private final TramiteRepository tramites;
  private final EventRepository events;
  private final DerivacionDAO derivaciones;

  public TramiteService() {
    this(Database::open, new TramiteDAO(), new HistorialDAO(), new DerivacionDAO());
  }

  public TramiteService(
      ConnectionProvider c, TramiteRepository t, EventRepository e, DerivacionDAO d) {
    connections = c;
    tramites = t;
    events = e;
    derivaciones = d;
  }

  public long guardar(Usuario u, Tramite t) throws SQLException {
    Access.staff(u);
    try (Connection c = connections.open()) {
      c.setAutoCommit(false);
      try {
        Map<String, Object> old = t.getId() == null ? null : tramites.bloquear(c, t.getId());
        if (t.getId() != null) {
          Access.tramite(u, old);
          if ("CONCLUIDO".equals(old.get("estado")))
            throw new IllegalArgumentException("Un trámite concluido no puede editarse.");
          transition(old.get("estado").toString(), t.getEstado());
          if (Sql.number(old.get("area_id")) != t.getAreaId())
            throw new IllegalArgumentException("Cambie el área mediante una derivación.");
        }
        Relations.area(c, u, t.getAreaId(), old == null ? null : Sql.number(old.get("area_id")));
        Relations.active(
            c, "tipos_tramite", t.getTipoId(), old == null ? null : Sql.number(old.get("tipo_id")));
        Relations.citizen(
            c,
            t.getCiudadanoId(),
            t.getIdentificacion(),
            old == null ? null : nullable(old.get("ciudadano_id")));
        Relations.document(
            c, u, t.getDocumentoId(), old == null ? null : nullable(old.get("documento_id")));
        long id;
        if (old == null) {
          t.setCodigo(code("TRA"));
          t.setUsuarioId(u.getId());
          id = tramites.registrar(c, t);
          events.registrar(
              c,
              id,
              u.getId(),
              "REGISTRO",
              "Registro inicial del trámite en el área " + t.getAreaId());
        } else {
          id = t.getId();
          tramites.actualizar(c, t);
          String prev = old.get("estado").toString();
          events.registrar(
              c,
              id,
              u.getId(),
              prev.equals(t.getEstado()) ? "EDICION" : "CAMBIO_ESTADO",
              prev.equals(t.getEstado())
                  ? "Actualización de los datos del expediente."
                  : "Estado: " + prev + " → " + t.getEstado());
        }
        c.commit();
        return id;
      } catch (SQLException | RuntimeException e) {
        c.rollback();
        throw e;
      }
    }
  }

  public void derivar(Usuario u, long id, long destino, String motivo, long version)
      throws SQLException {
    Access.staff(u);
    motivo = Validation.text(motivo, "Motivo de derivación", 1000);
    try (Connection c = connections.open()) {
      c.setAutoCommit(false);
      try {
        Map<String, Object> old = tramites.bloquear(c, id);
        Access.tramite(u, old);
        if (Sql.number(old.get("version")) != version)
          throw new IllegalArgumentException("El trámite cambió. Recargue antes de derivar.");
        if (Set.of("CONCLUIDO", "ATENDIDO").contains(old.get("estado")))
          throw new IllegalArgumentException("No puede derivar un trámite atendido o concluido.");
        long origen = Sql.number(old.get("area_id"));
        if (origen == destino)
          throw new IllegalArgumentException("Seleccione un área distinta del origen.");
        Relations.active(c, "areas", destino, null);
        Derivacion d = new Derivacion();
        d.setTramiteId(id);
        d.setAreaOrigenId(origen);
        d.setAreaDestinoId(destino);
        d.setUsuarioId(u.getId());
        d.setObservacion(motivo);
        derivaciones.registrar(c, d);
        tramites.cambiarArea(c, id, destino);
        Map<String, Object> a = Sql.one(c, "SELECT nombre FROM areas WHERE id=?", origen),
            b = Sql.one(c, "SELECT nombre FROM areas WHERE id=?", destino);
        events.registrar(
            c,
            id,
            u.getId(),
            "DERIVACION",
            a.get("nombre") + " → " + b.get("nombre") + ". " + motivo);
        c.commit();
      } catch (SQLException | RuntimeException e) {
        c.rollback();
        throw e;
      }
    }
  }

  public static void transition(String from, String to) {
    Map<String, Set<String>> rules =
        Map.of(
            "PENDIENTE",
            Set.of("PENDIENTE", "EN_PROCESO"),
            "DERIVADO",
            Set.of("DERIVADO", "EN_PROCESO"),
            "EN_PROCESO",
            Set.of("EN_PROCESO", "ATENDIDO"),
            "ATENDIDO",
            Set.of("ATENDIDO", "CONCLUIDO"),
            "CONCLUIDO",
            Set.of("CONCLUIDO"));
    if (!rules.getOrDefault(from, Set.of()).contains(to))
      throw new IllegalArgumentException(
          "Cambio de estado no permitido: "
              + from
              + " → "
              + to
              + ". Siga la secuencia de atención.");
  }

  public static String code(String prefix) {
    return prefix
        + "-"
        + UUID.randomUUID().toString().replace("-", "").substring(0, 16).toUpperCase(Locale.ROOT);
  }

  private static Long nullable(Object o) {
    return o == null ? null : Sql.number(o);
  }
}
