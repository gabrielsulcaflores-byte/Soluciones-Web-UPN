package pe.edu.solucionesweb.tramite.controller;

import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import java.util.*;
import pe.edu.solucionesweb.tramite.dao.*;
import pe.edu.solucionesweb.tramite.model.*;
import pe.edu.solucionesweb.tramite.service.*;
import pe.edu.solucionesweb.tramite.util.*;

@WebServlet("/usuarios")
public class UsuarioServlet extends BaseServlet {
  private final UsuarioDAO dao = new UsuarioDAO();
  private final UsuarioService service = new UsuarioService();

  protected void get(HttpServletRequest r, HttpServletResponse s) throws Exception {
    Access.admin(user(r));
    String action = p(r, "accion");
    if (action.equals("nuevo") || action.equals("editar")) {
      Map<String, Object> v = new HashMap<>();
      if (action.equals("editar")) {
        Usuario b = dao.obtener(id(r));
        if (b == null) throw new IllegalArgumentException("Usuario no encontrado.");
        v = b.toMap();
      }
      List<FormField> f = new ArrayList<>();
      f.add(field("nombres", "Nombres", "text", true, 100));
      f.add(field("apellido_paterno", "Apellido paterno", "text", true, 80));
      f.add(field("apellido_materno", "Apellido materno", "text", true, 80));
      f.add(field("dni", "DNI", "text", true, 8));
      f.add(field("correo", "Correo electrónico", "email", true, 160));
      f.add(
          field(
              "password",
              action.equals("nuevo")
                  ? "Contraseña (mínimo 12 caracteres)"
                  : "Nueva contraseña (opcional)",
              "password",
              action.equals("nuevo"),
              128));
      f.add(select("rol", "Rol", true, choices("ADMINISTRADOR", "FUNCIONARIO", "CIUDADANO")));
      f.add(
          select(
              "area_id",
              "Área (obligatoria para funcionario)",
              false,
              new AreaDAO()
                  .opciones(v.get("area_id") == null ? null : Sql.number(v.get("area_id")))));
      form(r, s, "Usuarios", v, f);
    } else {
      r.setAttribute("titulo", "Usuarios");
      r.setAttribute("filas", dao.listar(p(r, "q")));
      r.setAttribute(
          "columnas",
          Map.of(
              "nombre", "Nombre", "dni", "DNI", "correo", "Correo", "rol", "Rol", "area", "Área",
              "activo", "Activo"));
      r.setAttribute("orden", List.of("nombre", "dni", "correo", "rol", "area", "activo"));
      r.setAttribute("catalogo", true);
      view(r, s, "list");
    }
  }

  protected void post(HttpServletRequest r, HttpServletResponse s) throws Exception {
    Access.admin(user(r));
    if (p(r, "accion").equals("estado")) {
      service.estado(user(r), id(r), p(r, "activo").equals("true"));
    } else {
      Usuario u = new Usuario();
      u.setId(optional(r, "id"));
      u.setNombres(text(r, "nombres", "Nombres", 100));
      u.setApellidoPaterno(text(r, "apellido_paterno", "Apellido paterno", 80));
      u.setApellidoMaterno(text(r, "apellido_materno", "Apellido materno", 80));
      u.setDni(Validation.dni(p(r, "dni")));
      u.setCorreo(Validation.email(p(r, "correo")));
      u.setRol(Validation.choice(p(r, "rol"), "ADMINISTRADOR", "FUNCIONARIO", "CIUDADANO"));
      u.setAreaId(optional(r, "area_id"));
      String pw = r.getParameter("password");
      if (u.getId() == null || pw != null && !pw.isEmpty()) {
        Validation.password(pw);
        u.setPasswordHash(Password.hash(pw));
      }
      service.guardar(user(r), u);
    }
    success(r, s, "/usuarios", "Usuario actualizado correctamente.");
  }
}
