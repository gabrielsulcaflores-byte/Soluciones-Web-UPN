package pe.edu.solucionesweb.tramite.controller;

import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import pe.edu.solucionesweb.tramite.dao.*;
import pe.edu.solucionesweb.tramite.service.*;

@WebServlet("/historial")
public class HistorialServlet extends BaseServlet {
  protected void get(HttpServletRequest r, HttpServletResponse s) throws Exception {
    long id = id(r);
    var t = new TramiteDAO().detalle(id);
    Access.tramite(user(r), t);
    r.setAttribute("tramite", t);
    r.setAttribute("eventos", new HistorialDAO().listar(id));
    r.setAttribute("derivaciones", new DerivacionDAO().listar(id));
    view(r, s, "history");
  }
}
