package pe.edu.solucionesweb.tramite.model;

import java.util.*;
import pe.edu.solucionesweb.tramite.util.Sql;

public class TipoTramite {
  private Long id;

  public Long getId() {
    return id;
  }

  public void setId(Long value) {
    id = value;
  }

  private String nombre;

  public String getNombre() {
    return nombre;
  }

  public void setNombre(String value) {
    nombre = value;
  }

  private String descripcion;

  public String getDescripcion() {
    return descripcion;
  }

  public void setDescripcion(String value) {
    descripcion = value;
  }

  private Boolean activo;

  public Boolean getActivo() {
    return activo;
  }

  public void setActivo(Boolean value) {
    activo = value;
  }

  public static TipoTramite from(Map<String, Object> row) {
    if (row == null) return null;
    TipoTramite b = new TipoTramite();
    b.id = row.get("id") == null ? null : Sql.number(row.get("id"));
    b.nombre = row.get("nombre") == null ? null : row.get("nombre").toString();
    b.descripcion = row.get("descripcion") == null ? null : row.get("descripcion").toString();
    b.activo = Sql.active(row.get("activo"));
    return b;
  }

  public Map<String, Object> toMap() {
    Map<String, Object> m = new LinkedHashMap<>();
    m.put("id", id);
    m.put("nombre", nombre);
    m.put("descripcion", descripcion);
    m.put("activo", activo);
    return m;
  }
}
