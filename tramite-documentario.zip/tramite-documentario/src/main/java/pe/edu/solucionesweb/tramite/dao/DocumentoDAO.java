package pe.edu.solucionesweb.tramite.dao;

import java.sql.*;
import java.util.*;
import pe.edu.solucionesweb.tramite.model.*;
import pe.edu.solucionesweb.tramite.util.*;

public class DocumentoDAO {
  public Documento obtener(long id) throws SQLException {
    try (Connection c = Database.open()) {
      return Documento.from(Sql.one(c, "SELECT * FROM documentos WHERE id=?", id));
    }
  }

  public List<Map<String, Object>> listar(Usuario u, FiltroConsulta f) throws SQLException {
    try (Connection c = Database.open()) {
      String where = f.where(u, true);
      return Sql.query(
          c,
          "SELECT t.*,a.nombre area,CONCAT(u.nombres,' ',u.apellido_paterno) registrado_por FROM"
              + " documentos t JOIN areas a ON a.id=t.area_id JOIN usuarios u ON u.id=t.usuario_id"
              + where
              + " ORDER BY t.id DESC LIMIT 200",
          f.args.toArray());
    }
  }

  public List<Map<String, Object>> opciones(Usuario u, Long actual) throws SQLException {
    try (Connection c = Database.open()) {
      String scope = u.isAdmin() ? "" : " AND area_id=?";
      List<Object> args = new ArrayList<>();
      args.add(actual);
      if (!u.isAdmin()) args.add(u.getAreaId());
      return Sql.query(
          c,
          "SELECT id,CONCAT(codigo,' · ',asunto) nombre FROM documentos WHERE (estado<>'ANULADO' OR"
              + " id=?)"
              + scope
              + " ORDER BY id DESC LIMIT 500",
          args.toArray());
    }
  }

  public void registrar(Connection c, Documento d) throws SQLException {
    Sql.insert(
        c,
        "INSERT INTO"
            + " documentos(codigo,tipo_documento,remitente,identificacion,asunto,descripcion,fecha_recepcion,area_id,estado,usuario_id)"
            + " VALUES(?,?,?,?,?,?,?,?,?,?)",
        d.getCodigo(),
        d.getTipoDocumento(),
        d.getRemitente(),
        d.getIdentificacion(),
        d.getAsunto(),
        d.getDescripcion(),
        d.getFechaRecepcion(),
        d.getAreaId(),
        d.getEstado(),
        d.getUsuarioId());
  }

  public void actualizar(Connection c, Documento d) throws SQLException {
    int n =
        Sql.update(
            c,
            "UPDATE documentos SET"
                + " tipo_documento=?,remitente=?,identificacion=?,asunto=?,descripcion=?,fecha_recepcion=?,area_id=?,estado=?,version=version+1"
                + " WHERE id=? AND version=?",
            d.getTipoDocumento(),
            d.getRemitente(),
            d.getIdentificacion(),
            d.getAsunto(),
            d.getDescripcion(),
            d.getFechaRecepcion(),
            d.getAreaId(),
            d.getEstado(),
            d.getId(),
            d.getVersion());
    if (n != 1)
      throw new IllegalArgumentException("El documento cambió. Recargue antes de guardar.");
  }
}
