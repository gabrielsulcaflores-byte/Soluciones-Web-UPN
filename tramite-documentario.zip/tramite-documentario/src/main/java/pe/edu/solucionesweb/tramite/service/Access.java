package pe.edu.solucionesweb.tramite.service;

import java.util.Map;
import pe.edu.solucionesweb.tramite.model.Usuario;
import pe.edu.solucionesweb.tramite.util.Sql;

public final class Access {
  private Access() {}

  public static void admin(Usuario u) {
    if (!u.isAdmin())
      throw new SecurityException("Solo el administrador puede gestionar este módulo.");
  }

  public static void staff(Usuario u) {
    if (u.isCiudadano()) throw new SecurityException("Esta operación requiere un funcionario.");
  }

  public static void tramite(Usuario u, Map<String, Object> t) {
    if (t == null) throw new IllegalArgumentException("Trámite no encontrado.");
    if (u.isAdmin()) return;
    if (u.isCiudadano() && Sql.number(t.get("ciudadano_id")) == u.getId()) return;
    if (u.isFuncionario() && Sql.number(t.get("area_id")) == u.getAreaId()) return;
    throw new SecurityException("No tiene acceso a este trámite.");
  }

  public static void document(Usuario u, Map<String, Object> d) {
    staff(u);
    if (d == null) throw new IllegalArgumentException("Documento no encontrado.");
    if (!u.isAdmin() && Sql.number(d.get("area_id")) != u.getAreaId())
      throw new SecurityException("El documento pertenece a otra área.");
  }
}
