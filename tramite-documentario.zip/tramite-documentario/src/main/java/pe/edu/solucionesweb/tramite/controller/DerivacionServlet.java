package pe.edu.solucionesweb.tramite.controller;

import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import pe.edu.solucionesweb.tramite.dao.*;
import pe.edu.solucionesweb.tramite.service.*;

@WebServlet("/derivaciones")
public class DerivacionServlet extends BaseServlet {
  protected void get(HttpServletRequest r, HttpServletResponse s) throws Exception {
    Access.staff(user(r));
    Long id = optional(r, "id");
    if (id != null) {
      var t = new TramiteDAO().detalle(id);
      Access.tramite(user(r), t);
      r.setAttribute("tramite", t);
    }
    r.setAttribute("areas", new AreaDAO().opciones(null));
    view(r, s, "derive");
  }

  protected void post(HttpServletRequest r, HttpServletResponse s) throws Exception {
    new TramiteService()
        .derivar(
            user(r),
            id(r),
            pe.edu.solucionesweb.tramite.util.Validation.id(p(r, "area_destino_id")),
            p(r, "observacion"),
            Long.parseLong(p(r, "version")));
    success(
        r,
        s,
        "/derivaciones",
        "Derivación registrada correctamente. El área de destino tiene ahora el expediente.");
  }
}
