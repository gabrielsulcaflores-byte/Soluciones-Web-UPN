package pe.edu.solucionesweb.tramite.model;

import java.util.*;
import pe.edu.solucionesweb.tramite.util.Sql;

public class Documento {
  private Long id;

  public Long getId() {
    return id;
  }

  public void setId(Long value) {
    id = value;
  }

  private String codigo;

  public String getCodigo() {
    return codigo;
  }

  public void setCodigo(String value) {
    codigo = value;
  }

  private String tipoDocumento;

  public String getTipoDocumento() {
    return tipoDocumento;
  }

  public void setTipoDocumento(String value) {
    tipoDocumento = value;
  }

  private String remitente;

  public String getRemitente() {
    return remitente;
  }

  public void setRemitente(String value) {
    remitente = value;
  }

  private String identificacion;

  public String getIdentificacion() {
    return identificacion;
  }

  public void setIdentificacion(String value) {
    identificacion = value;
  }

  private String asunto;

  public String getAsunto() {
    return asunto;
  }

  public void setAsunto(String value) {
    asunto = value;
  }

  private String descripcion;

  public String getDescripcion() {
    return descripcion;
  }

  public void setDescripcion(String value) {
    descripcion = value;
  }

  private String fechaRecepcion;

  public String getFechaRecepcion() {
    return fechaRecepcion;
  }

  public void setFechaRecepcion(String value) {
    fechaRecepcion = value;
  }

  private Long areaId;

  public Long getAreaId() {
    return areaId;
  }

  public void setAreaId(Long value) {
    areaId = value;
  }

  private String estado;

  public String getEstado() {
    return estado;
  }

  public void setEstado(String value) {
    estado = value;
  }

  private Long usuarioId;

  public Long getUsuarioId() {
    return usuarioId;
  }

  public void setUsuarioId(Long value) {
    usuarioId = value;
  }

  private Long version;

  public Long getVersion() {
    return version;
  }

  public void setVersion(Long value) {
    version = value;
  }

  public static Documento from(Map<String, Object> row) {
    if (row == null) return null;
    Documento b = new Documento();
    b.id = row.get("id") == null ? null : Sql.number(row.get("id"));
    b.codigo = row.get("codigo") == null ? null : row.get("codigo").toString();
    b.tipoDocumento =
        row.get("tipo_documento") == null ? null : row.get("tipo_documento").toString();
    b.remitente = row.get("remitente") == null ? null : row.get("remitente").toString();
    b.identificacion =
        row.get("identificacion") == null ? null : row.get("identificacion").toString();
    b.asunto = row.get("asunto") == null ? null : row.get("asunto").toString();
    b.descripcion = row.get("descripcion") == null ? null : row.get("descripcion").toString();
    b.fechaRecepcion =
        row.get("fecha_recepcion") == null ? null : row.get("fecha_recepcion").toString();
    b.areaId = row.get("area_id") == null ? null : Sql.number(row.get("area_id"));
    b.estado = row.get("estado") == null ? null : row.get("estado").toString();
    b.usuarioId = row.get("usuario_id") == null ? null : Sql.number(row.get("usuario_id"));
    b.version = row.get("version") == null ? null : Sql.number(row.get("version"));
    return b;
  }

  public Map<String, Object> toMap() {
    Map<String, Object> m = new LinkedHashMap<>();
    m.put("id", id);
    m.put("codigo", codigo);
    m.put("tipo_documento", tipoDocumento);
    m.put("remitente", remitente);
    m.put("identificacion", identificacion);
    m.put("asunto", asunto);
    m.put("descripcion", descripcion);
    m.put("fecha_recepcion", fechaRecepcion);
    m.put("area_id", areaId);
    m.put("estado", estado);
    m.put("usuario_id", usuarioId);
    m.put("version", version);
    return m;
  }
}
