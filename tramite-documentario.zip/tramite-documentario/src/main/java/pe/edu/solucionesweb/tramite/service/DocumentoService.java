package pe.edu.solucionesweb.tramite.service;

import java.sql.*;
import java.util.*;
import pe.edu.solucionesweb.tramite.dao.DocumentoDAO;
import pe.edu.solucionesweb.tramite.model.*;
import pe.edu.solucionesweb.tramite.util.*;

public class DocumentoService {
  private final DocumentoDAO dao = new DocumentoDAO();

  public void guardar(Usuario u, Documento d) throws SQLException {
    Access.staff(u);
    try (Connection c = Database.open()) {
      c.setAutoCommit(false);
      try {
        Map<String, Object> old =
            d.getId() == null
                ? null
                : Sql.one(c, "SELECT * FROM documentos WHERE id=? FOR UPDATE", d.getId());
        if (d.getId() != null) {
          Access.document(u, old);
          if ("ANULADO".equals(old.get("estado")))
            throw new IllegalArgumentException("Un documento anulado no puede editarse.");
        }
        Relations.area(c, u, d.getAreaId(), old == null ? null : Sql.number(old.get("area_id")));
        if (d.getId() == null) {
          d.setCodigo(TramiteService.code("DOC"));
          d.setUsuarioId(u.getId());
          dao.registrar(c, d);
        } else dao.actualizar(c, d);
        c.commit();
      } catch (SQLException | RuntimeException e) {
        c.rollback();
        throw e;
      }
    }
  }
}
