package pe.edu.solucionesweb.tramite.util;

import java.sql.*;
import java.util.*;

/** Los SQL proceden exclusivamente de DAO; los valores se enlazan por parámetros. */
public final class Sql {
  private Sql() {}

  public static List<Map<String, Object>> query(Connection c, String sql, Object... args)
      throws SQLException {
    try (PreparedStatement p = c.prepareStatement(sql)) {
      bind(p, args);
      try (ResultSet r = p.executeQuery()) {
        List<Map<String, Object>> rows = new ArrayList<>();
        ResultSetMetaData m = r.getMetaData();
        while (r.next()) {
          Map<String, Object> row = new LinkedHashMap<>();
          for (int i = 1; i <= m.getColumnCount(); i++)
            row.put(m.getColumnLabel(i), r.getObject(i));
          rows.add(row);
        }
        return rows;
      }
    }
  }

  public static Map<String, Object> one(Connection c, String sql, Object... args)
      throws SQLException {
    List<Map<String, Object>> r = query(c, sql, args);
    return r.isEmpty() ? null : r.get(0);
  }

  public static int update(Connection c, String sql, Object... args) throws SQLException {
    try (PreparedStatement p = c.prepareStatement(sql)) {
      bind(p, args);
      return p.executeUpdate();
    }
  }

  public static long insert(Connection c, String sql, Object... args) throws SQLException {
    try (PreparedStatement p = c.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
      bind(p, args);
      p.executeUpdate();
      try (ResultSet r = p.getGeneratedKeys()) {
        if (!r.next()) throw new SQLException("No se generó identificador");
        return r.getLong(1);
      }
    }
  }

  private static void bind(PreparedStatement p, Object[] args) throws SQLException {
    for (int i = 0; i < args.length; i++) p.setObject(i + 1, args[i]);
  }

  public static long number(Object value) {
    return value == null ? 0 : ((Number) value).longValue();
  }

  public static boolean active(Object value) {
    return Boolean.TRUE.equals(value)
        || (value instanceof Number && ((Number) value).intValue() == 1);
  }
}
