package pe.edu.solucionesweb.tramite.util;

import java.io.*;
import java.nio.file.*;
import java.sql.*;
import java.util.Properties;

/** Configuración externa: variables de entorno o -Dtramite.config=ruta. */
public final class Database {
  private Database() {}

  public static Connection open() throws SQLException {
    Properties p = new Properties();
    String file = System.getProperty("tramite.config", System.getenv("TRAMITE_CONFIG"));
    if (file != null && !file.isBlank())
      try (Reader in =
          Files.newBufferedReader(Path.of(file), java.nio.charset.StandardCharsets.UTF_8)) {
        p.load(in);
      } catch (IOException e) {
        throw new SQLException("No se pudo leer la configuración externa", e);
      }
    String url =
        value(
            "DB_URL",
            p,
            "db.url",
            "jdbc:mysql://localhost:3306/tramite_documentario?connectionTimeZone=America/Lima&characterEncoding=UTF-8");
    String user = value("DB_USER", p, "db.user", "tramite_app");
    String pass = value("DB_PASSWORD", p, "db.password", null);
    if (pass == null) throw new SQLException("Configure DB_PASSWORD o TRAMITE_CONFIG");
    Connection connection = DriverManager.getConnection(url, user, pass);
    try (PreparedStatement statement = connection.prepareStatement("SET time_zone = ?")) {
      // America/Lima usa UTC-05:00; el desplazamiento evita depender de tablas de zonas de MySQL.
      statement.setString(1, "-05:00");
      statement.execute();
      return connection;
    } catch (SQLException e) {
      connection.close();
      throw e;
    }
  }

  private static String value(String env, Properties p, String key, String fallback) {
    String s = System.getenv(env);
    return s != null ? s : p.getProperty(key, fallback);
  }
}
