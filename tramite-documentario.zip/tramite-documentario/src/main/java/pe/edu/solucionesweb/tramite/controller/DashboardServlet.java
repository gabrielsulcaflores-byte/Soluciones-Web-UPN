package pe.edu.solucionesweb.tramite.controller;

import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import pe.edu.solucionesweb.tramite.dao.*;

@WebServlet("/dashboard")
public class DashboardServlet extends BaseServlet {
  protected void get(HttpServletRequest r, HttpServletResponse s) throws Exception {
    ReporteDAO d = new ReporteDAO();
    var states = d.estados(user(r), false);
    r.setAttribute("estados", states);
    r.setAttribute(
        "totalTramites",
        states.stream().mapToLong(x -> ((Number) x.get("total")).longValue()).sum());
    var docs = d.estados(user(r), true);
    r.setAttribute("documentos", docs);
    r.setAttribute(
        "totalDocumentos",
        docs.stream().mapToLong(x -> ((Number) x.get("total")).longValue()).sum());
    r.setAttribute("porArea", d.areas(user(r)));
    r.setAttribute("recientes", new TramiteDAO().listar(user(r), new FiltroConsulta(), 6));
    view(r, s, "dashboard");
  }
}
