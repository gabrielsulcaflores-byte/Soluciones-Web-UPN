package pe.edu.solucionesweb.tramite.model;

import java.util.*;
import pe.edu.solucionesweb.tramite.util.Sql;

public class HistorialTramite {
  private Long id;

  public Long getId() {
    return id;
  }

  public void setId(Long value) {
    id = value;
  }

  private Long tramiteId;

  public Long getTramiteId() {
    return tramiteId;
  }

  public void setTramiteId(Long value) {
    tramiteId = value;
  }

  private Long usuarioId;

  public Long getUsuarioId() {
    return usuarioId;
  }

  public void setUsuarioId(Long value) {
    usuarioId = value;
  }

  private String fecha;

  public String getFecha() {
    return fecha;
  }

  public void setFecha(String value) {
    fecha = value;
  }

  private String accion;

  public String getAccion() {
    return accion;
  }

  public void setAccion(String value) {
    accion = value;
  }

  private String descripcion;

  public String getDescripcion() {
    return descripcion;
  }

  public void setDescripcion(String value) {
    descripcion = value;
  }

  public static HistorialTramite from(Map<String, Object> row) {
    if (row == null) return null;
    HistorialTramite b = new HistorialTramite();
    b.id = row.get("id") == null ? null : Sql.number(row.get("id"));
    b.tramiteId = row.get("tramite_id") == null ? null : Sql.number(row.get("tramite_id"));
    b.usuarioId = row.get("usuario_id") == null ? null : Sql.number(row.get("usuario_id"));
    b.fecha = row.get("fecha") == null ? null : row.get("fecha").toString();
    b.accion = row.get("accion") == null ? null : row.get("accion").toString();
    b.descripcion = row.get("descripcion") == null ? null : row.get("descripcion").toString();
    return b;
  }

  public Map<String, Object> toMap() {
    Map<String, Object> m = new LinkedHashMap<>();
    m.put("id", id);
    m.put("tramite_id", tramiteId);
    m.put("usuario_id", usuarioId);
    m.put("fecha", fecha);
    m.put("accion", accion);
    m.put("descripcion", descripcion);
    return m;
  }
}
