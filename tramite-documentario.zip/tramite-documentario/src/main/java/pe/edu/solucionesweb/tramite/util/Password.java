package pe.edu.solucionesweb.tramite.util;

import java.security.*;
import java.util.Base64;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.PBEKeySpec;

/** PBKDF2-HMAC-SHA256, sal aleatoria por contraseña, comparación constante. */
public final class Password {
  private static final int ITERATIONS = 600000;

  private Password() {}

  public static String hash(String password) {
    byte[] salt = new byte[16];
    new SecureRandom().nextBytes(salt);
    return "pbkdf2$"
        + ITERATIONS
        + "$"
        + Base64.getEncoder().encodeToString(salt)
        + "$"
        + Base64.getEncoder().encodeToString(derive(password, salt, ITERATIONS));
  }

  public static boolean verify(String password, String encoded) {
    try {
      String[] a = encoded.split("\\$");
      int n = Integer.parseInt(a[1]);
      if (a.length != 4 || !a[0].equals("pbkdf2") || n < 100000 || n > 2000000) return false;
      return MessageDigest.isEqual(
          Base64.getDecoder().decode(a[3]), derive(password, Base64.getDecoder().decode(a[2]), n));
    } catch (RuntimeException e) {
      return false;
    }
  }

  private static byte[] derive(String p, byte[] salt, int n) {
    PBEKeySpec spec = new PBEKeySpec(p.toCharArray(), salt, n, 256);
    try {
      return SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(spec).getEncoded();
    } catch (GeneralSecurityException e) {
      throw new IllegalStateException(e);
    } finally {
      spec.clearPassword();
    }
  }
}
