package pe.edu.solucionesweb.tramite.model;

import java.util.*;

/** Metadatos de presentación compartidos por formularios JSP. No contiene SQL. */
public class FormField {
  private final String name, label, type;
  private final boolean required;
  private final int max;
  private final List<Map<String, Object>> options;

  public FormField(
      String name,
      String label,
      String type,
      boolean required,
      int max,
      List<Map<String, Object>> options) {
    this.name = name;
    this.label = label;
    this.type = type;
    this.required = required;
    this.max = max;
    this.options = options;
  }

  public String getName() {
    return name;
  }

  public String getLabel() {
    return label;
  }

  public String getType() {
    return type;
  }

  public boolean isRequired() {
    return required;
  }

  public int getMax() {
    return max;
  }

  public List<Map<String, Object>> getOptions() {
    return options;
  }
}
