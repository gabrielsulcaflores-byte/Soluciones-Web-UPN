package pe.edu.solucionesweb.tramite.model;

import java.util.*;
import pe.edu.solucionesweb.tramite.util.Sql;

public class Tramite {
  private Long id;

  public Long getId() {
    return id;
  }

  public void setId(Long value) {
    id = value;
  }

  private String codigo;

  public String getCodigo() {
    return codigo;
  }

  public void setCodigo(String value) {
    codigo = value;
  }

  private Long tipoId;

  public Long getTipoId() {
    return tipoId;
  }

  public void setTipoId(Long value) {
    tipoId = value;
  }

  private String solicitante;

  public String getSolicitante() {
    return solicitante;
  }

  public void setSolicitante(String value) {
    solicitante = value;
  }

  private String identificacion;

  public String getIdentificacion() {
    return identificacion;
  }

  public void setIdentificacion(String value) {
    identificacion = value;
  }

  private Long ciudadanoId;

  public Long getCiudadanoId() {
    return ciudadanoId;
  }

  public void setCiudadanoId(Long value) {
    ciudadanoId = value;
  }

  private Long documentoId;

  public Long getDocumentoId() {
    return documentoId;
  }

  public void setDocumentoId(Long value) {
    documentoId = value;
  }

  private String asunto;

  public String getAsunto() {
    return asunto;
  }

  public void setAsunto(String value) {
    asunto = value;
  }

  private String descripcion;

  public String getDescripcion() {
    return descripcion;
  }

  public void setDescripcion(String value) {
    descripcion = value;
  }

  private String fechaRegistro;

  public String getFechaRegistro() {
    return fechaRegistro;
  }

  public void setFechaRegistro(String value) {
    fechaRegistro = value;
  }

  private Long areaId;

  public Long getAreaId() {
    return areaId;
  }

  public void setAreaId(Long value) {
    areaId = value;
  }

  private String estado;

  public String getEstado() {
    return estado;
  }

  public void setEstado(String value) {
    estado = value;
  }

  private Long usuarioId;

  public Long getUsuarioId() {
    return usuarioId;
  }

  public void setUsuarioId(Long value) {
    usuarioId = value;
  }

  private Long version;

  public Long getVersion() {
    return version;
  }

  public void setVersion(Long value) {
    version = value;
  }

  public static Tramite from(Map<String, Object> row) {
    if (row == null) return null;
    Tramite b = new Tramite();
    b.id = row.get("id") == null ? null : Sql.number(row.get("id"));
    b.codigo = row.get("codigo") == null ? null : row.get("codigo").toString();
    b.tipoId = row.get("tipo_id") == null ? null : Sql.number(row.get("tipo_id"));
    b.solicitante = row.get("solicitante") == null ? null : row.get("solicitante").toString();
    b.identificacion =
        row.get("identificacion") == null ? null : row.get("identificacion").toString();
    b.ciudadanoId = row.get("ciudadano_id") == null ? null : Sql.number(row.get("ciudadano_id"));
    b.documentoId = row.get("documento_id") == null ? null : Sql.number(row.get("documento_id"));
    b.asunto = row.get("asunto") == null ? null : row.get("asunto").toString();
    b.descripcion = row.get("descripcion") == null ? null : row.get("descripcion").toString();
    b.fechaRegistro =
        row.get("fecha_registro") == null ? null : row.get("fecha_registro").toString();
    b.areaId = row.get("area_id") == null ? null : Sql.number(row.get("area_id"));
    b.estado = row.get("estado") == null ? null : row.get("estado").toString();
    b.usuarioId = row.get("usuario_id") == null ? null : Sql.number(row.get("usuario_id"));
    b.version = row.get("version") == null ? null : Sql.number(row.get("version"));
    return b;
  }

  public Map<String, Object> toMap() {
    Map<String, Object> m = new LinkedHashMap<>();
    m.put("id", id);
    m.put("codigo", codigo);
    m.put("tipo_id", tipoId);
    m.put("solicitante", solicitante);
    m.put("identificacion", identificacion);
    m.put("ciudadano_id", ciudadanoId);
    m.put("documento_id", documentoId);
    m.put("asunto", asunto);
    m.put("descripcion", descripcion);
    m.put("fecha_registro", fechaRegistro);
    m.put("area_id", areaId);
    m.put("estado", estado);
    m.put("usuario_id", usuarioId);
    m.put("version", version);
    return m;
  }
}
