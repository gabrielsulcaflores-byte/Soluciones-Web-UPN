package pe.edu.solucionesweb.tramite.dao;

import java.sql.*;
import java.util.*;
import pe.edu.solucionesweb.tramite.util.*;

public class HistorialDAO implements EventRepository {
  public void registrar(Connection c, long tramite, long usuario, String accion, String descripcion)
      throws SQLException {
    Sql.insert(
        c,
        "INSERT INTO historial_tramites(tramite_id,usuario_id,accion,descripcion) VALUES(?,?,?,?)",
        tramite,
        usuario,
        accion,
        descripcion);
  }

  public List<Map<String, Object>> listar(long tramite) throws SQLException {
    try (Connection c = Database.open()) {
      return Sql.query(
          c,
          "SELECT h.*,CONCAT(u.nombres,' ',u.apellido_paterno) responsable FROM historial_tramites"
              + " h JOIN usuarios u ON u.id=h.usuario_id WHERE h.tramite_id=? ORDER BY"
              + " h.fecha,h.id",
          tramite);
    }
  }
}
