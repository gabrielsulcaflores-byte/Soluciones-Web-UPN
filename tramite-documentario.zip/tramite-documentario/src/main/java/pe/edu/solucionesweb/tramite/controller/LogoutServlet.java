package pe.edu.solucionesweb.tramite.controller;

import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;

@WebServlet("/logout")
public class LogoutServlet extends BaseServlet {
  protected void get(HttpServletRequest r, HttpServletResponse s) throws Exception {
    s.setStatus(405);
    view(r, s, "denied");
  }

  protected void post(HttpServletRequest r, HttpServletResponse s) throws Exception {
    r.getSession().invalidate();
    s.sendRedirect(r.getContextPath() + "/login");
  }
}
