package pe.edu.solucionesweb.tramite.util;

import java.sql.Connection;

/** Diagnóstico de conexión sin revelar credenciales. */
public class CheckDatabase {
  public static void main(String[] args) {
    try (Connection connection = Database.open()) {
      var row = Sql.one(connection, "SELECT VERSION() version, DATABASE() nombre");
      var count = Sql.one(connection, "SELECT COUNT(*) total FROM areas");
      System.out.println("Conexión correcta. MySQL " + row.get("version"));
      System.out.println("Base: " + row.get("nombre") + ". Áreas: " + count.get("total"));
    } catch (Exception e) {
      System.err.println(
          "No se pudo conectar o falta importar el esquema. Verifique servicio, puerto, usuario,"
              + " contraseña y TRAMITE_CONFIG.");
      System.exit(1);
    }
  }
}
