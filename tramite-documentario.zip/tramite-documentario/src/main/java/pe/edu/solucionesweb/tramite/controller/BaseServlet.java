package pe.edu.solucionesweb.tramite.controller;

import jakarta.servlet.*;
import jakarta.servlet.http.*;
import java.io.*;
import java.sql.*;
import java.util.*;
import pe.edu.solucionesweb.tramite.dao.*;
import pe.edu.solucionesweb.tramite.model.*;
import pe.edu.solucionesweb.tramite.util.*;

/** Flujo común: validación, mensajes controlados y patrón Post/Redirect/Get. */
public abstract class BaseServlet extends HttpServlet {
  protected abstract void get(HttpServletRequest r, HttpServletResponse s) throws Exception;

  protected void post(HttpServletRequest r, HttpServletResponse s) throws Exception {
    throw new IllegalArgumentException("Acción no disponible.");
  }

  @Override
  protected final void doGet(HttpServletRequest r, HttpServletResponse s)
      throws ServletException, IOException {
    execute(r, s, false);
  }

  @Override
  protected final void doPost(HttpServletRequest r, HttpServletResponse s)
      throws ServletException, IOException {
    execute(r, s, true);
  }

  private void execute(HttpServletRequest r, HttpServletResponse s, boolean post)
      throws ServletException, IOException {
    try {
      r.setAttribute("ruta", r.getServletPath());
      if (post) post(r, s);
      else get(r, s);
    } catch (SecurityException e) {
      s.setStatus(403);
      r.setAttribute("error", e.getMessage());
      view(r, s, "denied");
    } catch (IllegalArgumentException e) {
      s.setStatus(400);
      r.setAttribute("error", e.getMessage());
      view(r, s, "error");
    } catch (Exception e) {
      getServletContext().log("Error en operación " + r.getServletPath(), e);
      s.setStatus(500);
      String msg =
          "No se pudo completar la operación. Revise la configuración o inténtelo nuevamente.";
      if (e instanceof SQLException && "23000".equals(((SQLException) e).getSQLState())) {
        s.setStatus(409);
        msg =
            "Los datos ya existen o una relación impide la operación. Revise DNI, correo, nombre y"
                + " selecciones.";
      }
      r.setAttribute("error", msg);
      view(r, s, "error");
    }
  }

  protected Usuario user(HttpServletRequest r) {
    return (Usuario) r.getSession().getAttribute("usuario");
  }

  protected String p(HttpServletRequest r, String key) {
    return Objects.toString(r.getParameter(key), "").trim();
  }

  protected Long optional(HttpServletRequest r, String key) {
    return Validation.optionalId(p(r, key));
  }

  protected long id(HttpServletRequest r) {
    return Validation.id(p(r, "id"));
  }

  protected String text(HttpServletRequest r, String key, String label, int max) {
    return Validation.text(p(r, key), label, max);
  }

  protected void view(HttpServletRequest r, HttpServletResponse s, String name)
      throws ServletException, IOException {
    r.getRequestDispatcher("/WEB-INF/views/" + name + ".jsp").forward(r, s);
  }

  protected void success(HttpServletRequest r, HttpServletResponse s, String route, String msg)
      throws IOException {
    r.getSession().setAttribute("flash", msg);
    s.sendRedirect(r.getContextPath() + route);
  }

  protected void form(
      HttpServletRequest r,
      HttpServletResponse s,
      String title,
      Map<String, Object> values,
      List<FormField> fields)
      throws Exception {
    r.setAttribute("titulo", title);
    r.setAttribute("valores", values);
    r.setAttribute("campos", fields);
    view(r, s, "form");
  }

  protected FormField field(String n, String label, String type, boolean required, int max) {
    return new FormField(n, label, type, required, max, List.of());
  }

  protected FormField select(
      String n, String label, boolean required, List<Map<String, Object>> opts) {
    return new FormField(n, label, "select", required, 0, opts);
  }

  protected List<Map<String, Object>> choices(String... values) {
    List<Map<String, Object>> out = new ArrayList<>();
    for (String v : values) out.add(Map.of("id", v, "nombre", v.replace('_', ' ')));
    return out;
  }

  protected FiltroConsulta filters(HttpServletRequest r) {
    FiltroConsulta f = new FiltroConsulta();
    f.q = p(r, "q");
    if (f.q.length() > 200) throw new IllegalArgumentException("La búsqueda es demasiado larga.");
    f.estado = p(r, "estado");
    f.area = optional(r, "area");
    f.tipo = optional(r, "tipo");
    f.desde = p(r, "desde");
    f.hasta = p(r, "hasta");
    if (!f.desde.isBlank()) Validation.date(f.desde);
    if (!f.hasta.isBlank()) Validation.date(f.hasta);
    if (!f.desde.isBlank() && !f.hasta.isBlank() && f.desde.compareTo(f.hasta) > 0)
      throw new IllegalArgumentException("El rango de fechas es inválido.");
    return f;
  }

  protected void filterOptions(HttpServletRequest r, boolean docs) throws SQLException {
    r.setAttribute("areas", new AreaDAO().opciones(null));
    r.setAttribute("tipos", new TipoTramiteDAO().opciones(null));
    r.setAttribute(
        "estados",
        docs
            ? choices("RECIBIDO", "EN_REVISION", "ARCHIVADO", "ANULADO")
            : choices("PENDIENTE", "EN_PROCESO", "DERIVADO", "ATENDIDO", "CONCLUIDO"));
  }
}
