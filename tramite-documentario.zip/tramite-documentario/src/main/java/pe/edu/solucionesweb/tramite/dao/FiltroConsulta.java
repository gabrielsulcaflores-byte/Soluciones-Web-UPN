package pe.edu.solucionesweb.tramite.dao;

import java.util.*;
import pe.edu.solucionesweb.tramite.model.Usuario;

/** Construye únicamente condiciones conocidas; todos los valores quedan parametrizados. */
public class FiltroConsulta {
  public String q = "", estado = "", desde = "", hasta = "";
  public Long area, tipo;
  public final List<Object> args = new ArrayList<>();

  public String where(Usuario u, boolean documentos) {
    args.clear();
    String s = " WHERE 1=1 ";
    if (u.isCiudadano()) {
      if (documentos) {
        s += " AND 1=0 ";
      } else {
        s += " AND t.ciudadano_id=? ";
        args.add(u.getId());
      }
    }
    if (u.isFuncionario()) {
      s += " AND t.area_id=? ";
      args.add(u.getAreaId());
    }
    if (!q.isBlank()) {
      s +=
          " AND CONCAT(t.codigo,' ',t.asunto,' ',t."
              + (documentos ? "remitente" : "solicitante")
              + ",' ',t.identificacion) LIKE ? ";
      args.add("%" + q + "%");
    }
    if (!estado.isBlank()) {
      s += " AND t.estado=? ";
      args.add(estado);
    }
    if (area != null) {
      s += " AND t.area_id=? ";
      args.add(area);
    }
    if (tipo != null && !documentos) {
      s += " AND t.tipo_id=? ";
      args.add(tipo);
    }
    String date = documentos ? "t.fecha_recepcion" : "t.fecha_registro";
    if (!desde.isBlank()) {
      s += " AND " + date + ">=? ";
      args.add(desde);
    }
    if (!hasta.isBlank()) {
      s += " AND " + date + "<DATE_ADD(?,INTERVAL 1 DAY) ";
      args.add(hasta);
    }
    return s;
  }
}
