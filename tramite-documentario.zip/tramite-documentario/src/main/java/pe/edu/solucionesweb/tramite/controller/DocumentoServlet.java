package pe.edu.solucionesweb.tramite.controller;

import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import java.util.*;
import pe.edu.solucionesweb.tramite.dao.*;
import pe.edu.solucionesweb.tramite.model.*;
import pe.edu.solucionesweb.tramite.service.*;
import pe.edu.solucionesweb.tramite.util.*;

@WebServlet("/documentos")
public class DocumentoServlet extends BaseServlet {
  private final DocumentoDAO dao = new DocumentoDAO();

  protected void get(HttpServletRequest r, HttpServletResponse s) throws Exception {
    Access.staff(user(r));
    String action = p(r, "accion");
    if (action.equals("nuevo") || action.equals("editar")) {
      Map<String, Object> v = new HashMap<>();
      v.put(
          "fecha_recepcion",
          java.time.LocalDate.now(java.time.ZoneId.of("America/Lima")).toString());
      v.put("estado", "RECIBIDO");
      if (action.equals("editar")) {
        Documento d = dao.obtener(id(r));
        Access.document(user(r), d == null ? null : d.toMap());
        v = d.toMap();
      }
      List<FormField> f = new ArrayList<>();
      f.add(
          select(
              "tipo_documento",
              "Tipo de documento",
              true,
              choices("Solicitud", "Oficio", "Carta", "Informe", "Memorando", "Otro")));
      f.add(field("remitente", "Remitente", "text", true, 180));
      f.add(field("identificacion", "DNI o RUC del remitente", "text", true, 11));
      f.add(field("asunto", "Asunto", "text", true, 200));
      f.add(field("descripcion", "Descripción", "textarea", true, 5000));
      f.add(field("fecha_recepcion", "Fecha de recepción", "date", true, 10));
      f.add(
          select(
              "area_id",
              "Área de destino",
              true,
              user(r).isAdmin()
                  ? new AreaDAO()
                      .opciones(v.get("area_id") == null ? null : Sql.number(v.get("area_id")))
                  : new AreaDAO()
                      .opciones(user(r).getAreaId()).stream()
                          .filter(x -> Sql.number(x.get("id")) == user(r).getAreaId())
                          .toList()));
      f.add(
          select(
              "estado",
              "Estado",
              true,
              choices("RECIBIDO", "EN_REVISION", "ARCHIVADO", "ANULADO")));
      form(r, s, "Documentos", v, f);
    } else {
      filterOptions(r, true);
      r.setAttribute("titulo", "Documentos");
      r.setAttribute("filas", dao.listar(user(r), filters(r)));
      r.setAttribute(
          "columnas",
          Map.of(
              "codigo",
              "Código",
              "remitente",
              "Remitente",
              "asunto",
              "Asunto",
              "area",
              "Área",
              "estado",
              "Estado",
              "fecha_recepcion",
              "Recepción"));
      r.setAttribute(
          "orden", List.of("codigo", "remitente", "asunto", "area", "estado", "fecha_recepcion"));
      r.setAttribute("filtros", true);
      view(r, s, "list");
    }
  }

  protected void post(HttpServletRequest r, HttpServletResponse s) throws Exception {
    Documento d = new Documento();
    d.setId(optional(r, "id"));
    d.setVersion(d.getId() == null ? 0 : Long.parseLong(p(r, "version")));
    d.setTipoDocumento(
        Validation.choice(
            p(r, "tipo_documento"),
            "Solicitud",
            "Oficio",
            "Carta",
            "Informe",
            "Memorando",
            "Otro"));
    d.setRemitente(text(r, "remitente", "Remitente", 180));
    d.setIdentificacion(Validation.identification(p(r, "identificacion")));
    d.setAsunto(text(r, "asunto", "Asunto", 200));
    d.setDescripcion(text(r, "descripcion", "Descripción", 5000));
    d.setFechaRecepcion(Validation.date(p(r, "fecha_recepcion")).toString());
    d.setAreaId(Validation.id(p(r, "area_id")));
    d.setEstado(
        Validation.choice(p(r, "estado"), "RECIBIDO", "EN_REVISION", "ARCHIVADO", "ANULADO"));
    new DocumentoService().guardar(user(r), d);
    success(r, s, "/documentos", "Documento guardado correctamente.");
  }
}
