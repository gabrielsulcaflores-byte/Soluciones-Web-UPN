package pe.edu.solucionesweb.tramite.dao;

import java.sql.*;
import java.util.Map;
import pe.edu.solucionesweb.tramite.model.Tramite;

/** Contrato pequeño utilizado por la lógica transaccional. */
public interface TramiteRepository {
  Map<String, Object> bloquear(Connection c, long id) throws SQLException;

  long registrar(Connection c, Tramite t) throws SQLException;

  void actualizar(Connection c, Tramite t) throws SQLException;

  void cambiarArea(Connection c, long id, long area) throws SQLException;
}
