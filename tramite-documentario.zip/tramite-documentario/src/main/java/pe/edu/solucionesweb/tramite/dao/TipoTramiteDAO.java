package pe.edu.solucionesweb.tramite.dao;

import java.sql.*;
import java.util.*;
import pe.edu.solucionesweb.tramite.model.TipoTramite;
import pe.edu.solucionesweb.tramite.util.*;

public class TipoTramiteDAO {
  public TipoTramite obtener(long id) throws SQLException {
    try (Connection c = Database.open()) {
      return TipoTramite.from(Sql.one(c, "SELECT * FROM tipos_tramite WHERE id=?", id));
    }
  }

  public List<Map<String, Object>> listar(String q) throws SQLException {
    try (Connection c = Database.open()) {
      return Sql.query(
          c,
          "SELECT * FROM tipos_tramite WHERE CONCAT(nombre,' ',descripcion) LIKE ? ORDER BY nombre"
              + " LIMIT 200",
          "%" + q + "%");
    }
  }

  public List<Map<String, Object>> opciones(Long actual) throws SQLException {
    try (Connection c = Database.open()) {
      return Sql.query(
          c,
          "SELECT id,CONCAT(nombre,IF(activo=1,'',' (inactivo)')) nombre FROM tipos_tramite WHERE"
              + " activo=1 OR id=? ORDER BY nombre",
          actual);
    }
  }

  public void guardar(TipoTramite b) throws SQLException {
    try (Connection c = Database.open()) {
      if (b.getId() == null)
        Sql.insert(
            c,
            "INSERT INTO tipos_tramite(nombre,descripcion) VALUES(?,?)",
            b.getNombre(),
            b.getDescripcion());
      else if (Sql.update(
                  c,
                  "UPDATE tipos_tramite SET nombre=?,descripcion=? WHERE id=?",
                  b.getNombre(),
                  b.getDescripcion(),
                  b.getId())
              == 0
          && Sql.one(c, "SELECT id FROM tipos_tramite WHERE id=?", b.getId()) == null)
        throw new IllegalArgumentException("Registro no encontrado.");
    }
  }

  public void estado(long id, boolean activo) throws SQLException {
    try (Connection c = Database.open()) {
      if (Sql.update(c, "UPDATE tipos_tramite SET activo=? WHERE id=?", activo, id) == 0
          && Sql.one(c, "SELECT id FROM tipos_tramite WHERE id=?", id) == null)
        throw new IllegalArgumentException("Registro no encontrado.");
    }
  }
}
