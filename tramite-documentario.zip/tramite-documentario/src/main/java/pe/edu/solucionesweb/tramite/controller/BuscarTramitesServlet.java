package pe.edu.solucionesweb.tramite.controller;

import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import pe.edu.solucionesweb.tramite.dao.*;
import pe.edu.solucionesweb.tramite.service.*;

@WebServlet("/buscar-tramites")
public class BuscarTramitesServlet extends BaseServlet {
  protected void get(HttpServletRequest r, HttpServletResponse s) throws Exception {
    Access.staff(user(r));
    FiltroConsulta f = filters(r);
    var rows = new TramiteDAO().listar(user(r), f, 20);
    s.setContentType("application/xml;charset=UTF-8");
    var out = s.getWriter();
    out.print("<?xml version='1.0' encoding='UTF-8'?><tramites>");
    for (var t : rows)
      out.print(
          "<tramite><id>"
              + t.get("id")
              + "</id><codigo>"
              + xml(t.get("codigo"))
              + "</codigo><asunto>"
              + xml(t.get("asunto"))
              + "</asunto><area>"
              + xml(t.get("area"))
              + "</area></tramite>");
    out.print("</tramites>");
  }

  private String xml(Object o) {
    return String.valueOf(o)
        .replace("&", "&amp;")
        .replace("<", "&lt;")
        .replace(">", "&gt;")
        .replace("\"", "&quot;")
        .replace("'", "&apos;");
  }
}
