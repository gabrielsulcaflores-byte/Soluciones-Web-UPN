package pe.edu.solucionesweb.tramite.filter;

import jakarta.servlet.*;
import jakarta.servlet.annotation.WebFilter;
import jakarta.servlet.http.*;
import java.io.*;
import java.util.*;
import pe.edu.solucionesweb.tramite.dao.UsuarioDAO;
import pe.edu.solucionesweb.tramite.model.Usuario;

@WebFilter("/*")
public class SecurityFilter implements Filter {
  public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
      throws IOException, ServletException {
    HttpServletRequest r = (HttpServletRequest) request;
    HttpServletResponse s = (HttpServletResponse) response;
    r.setCharacterEncoding("UTF-8");
    s.setCharacterEncoding("UTF-8");
    s.setHeader("X-Content-Type-Options", "nosniff");
    s.setHeader("X-Frame-Options", "DENY");
    s.setHeader("Referrer-Policy", "same-origin");
    s.setHeader(
        "Content-Security-Policy",
        "default-src 'self'; style-src 'self'; script-src 'self'; img-src 'self' data:;"
            + " frame-ancestors 'none'; base-uri 'self'; form-action 'self'");
    String path = r.getServletPath();
    if (path.startsWith("/assets/")) {
      chain.doFilter(r, s);
      return;
    }
    s.setHeader("Cache-Control", "no-store");
    HttpSession session = r.getSession();
    if (session.getAttribute("csrf") == null)
      session.setAttribute("csrf", UUID.randomUUID().toString());
    if (!Set.of("GET", "POST", "HEAD").contains(r.getMethod())) {
      s.sendError(405);
      return;
    }
    if (r.getMethod().equals("POST")
        && !Objects.equals(session.getAttribute("csrf"), r.getParameter("csrf"))) {
      deny(r, s, "El formulario venció. Recargue la página.");
      return;
    }
    Usuario u = (Usuario) session.getAttribute("usuario");
    if (u != null) {
      try {
        u = new UsuarioDAO().obtener(u.getId());
        if (u == null || !Boolean.TRUE.equals(u.getActivo())) {
          session.invalidate();
          s.sendRedirect(r.getContextPath() + "/login");
          return;
        }
        u.setPasswordHash(null);
        session.setAttribute("usuario", u);
      } catch (Exception e) {
        r.getServletContext().log("No se pudo validar la sesión", e);
        s.setStatus(503);
        r.setAttribute("error", "No se pudo acceder a MySQL. Revise la configuración.");
        r.getRequestDispatcher("/WEB-INF/views/error.jsp").forward(r, s);
        return;
      }
    }
    boolean publicPath = path.equals("/login") || path.equals("/") || path.equals("/index.jsp");
    if (!publicPath && u == null) {
      s.sendRedirect(r.getContextPath() + "/login");
      return;
    }
    if (u != null) {
      boolean admin = Set.of("/usuarios", "/areas", "/tipos").contains(path);
      boolean staff = Set.of("/documentos", "/derivaciones", "/buscar-tramites").contains(path);
      if ((admin && !u.isAdmin()) || (staff && u.isCiudadano())) {
        deny(r, s, "No tiene permisos para este módulo.");
        return;
      }
    }
    chain.doFilter(r, s);
  }

  private void deny(HttpServletRequest r, HttpServletResponse s, String msg)
      throws IOException, ServletException {
    s.setStatus(403);
    r.setAttribute("error", msg);
    r.getRequestDispatcher("/WEB-INF/views/denied.jsp").forward(r, s);
  }
}
