package pe.edu.solucionesweb.tramite.dao;

import java.sql.*;

public interface EventRepository {
  void registrar(Connection c, long tramite, long usuario, String accion, String descripcion)
      throws SQLException;
}
