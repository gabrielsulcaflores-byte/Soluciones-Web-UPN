package pe.edu.solucionesweb.tramite.util;

import java.time.LocalDate;
import java.util.Set;

public final class Validation {
  private Validation() {}

  public static String text(String s, String label, int max) {
    if (s == null || s.trim().isEmpty())
      throw new IllegalArgumentException(label + " es obligatorio.");
    s = s.trim();
    if (s.length() > max)
      throw new IllegalArgumentException(label + " supera " + max + " caracteres.");
    return s;
  }

  public static String dni(String s) {
    s = text(s, "DNI", 8);
    if (!s.matches("[0-9]{8}")) throw new IllegalArgumentException("El DNI debe tener 8 dígitos.");
    return s;
  }

  public static String identification(String s) {
    s = text(s, "DNI o RUC", 11);
    if (!s.matches("([0-9]{8}|[0-9]{11})"))
      throw new IllegalArgumentException("Ingrese DNI de 8 dígitos o RUC de 11.");
    return s;
  }

  public static String email(String s) {
    s = text(s, "Correo", 160).toLowerCase(java.util.Locale.ROOT);
    if (!s.matches("[^\\s@]+@[^\\s@]+\\.[^\\s@]+"))
      throw new IllegalArgumentException("Correo inválido.");
    return s;
  }

  public static long id(String s) {
    try {
      long n = Long.parseLong(s);
      if (n <= 0) throw new NumberFormatException();
      return n;
    } catch (Exception e) {
      throw new IllegalArgumentException("Identificador inválido.");
    }
  }

  public static Long optionalId(String s) {
    return s == null || s.isBlank() ? null : id(s);
  }

  public static String choice(String s, String... allowed) {
    if (!Set.of(allowed).contains(s)) throw new IllegalArgumentException("Opción inválida.");
    return s;
  }

  public static LocalDate date(String s) {
    try {
      return LocalDate.parse(s);
    } catch (Exception e) {
      throw new IllegalArgumentException("Fecha inválida.");
    }
  }

  public static void password(String s) {
    if (s == null || s.length() < 12 || s.length() > 128)
      throw new IllegalArgumentException("La contraseña debe tener entre 12 y 128 caracteres.");
  }
}
