package pe.edu.solucionesweb.tramite.dao;

import java.sql.*;
import java.util.*;
import pe.edu.solucionesweb.tramite.model.Usuario;
import pe.edu.solucionesweb.tramite.util.*;

public class ReporteDAO {
  public List<Map<String, Object>> estados(Usuario u, boolean docs) throws SQLException {
    try (Connection c = Database.open()) {
      FiltroConsulta f = new FiltroConsulta();
      String where = f.where(u, docs);
      return Sql.query(
          c,
          "SELECT t.estado,COUNT(*) total FROM "
              + (docs ? "documentos" : "tramites")
              + " t"
              + where
              + " GROUP BY t.estado ORDER BY total DESC",
          f.args.toArray());
    }
  }

  public List<Map<String, Object>> areas(Usuario u) throws SQLException {
    try (Connection c = Database.open()) {
      FiltroConsulta f = new FiltroConsulta();
      String where = f.where(u, false);
      return Sql.query(
          c,
          "SELECT a.nombre,COUNT(*) total FROM tramites t JOIN areas a ON a.id=t.area_id"
              + where
              + " GROUP BY a.id,a.nombre ORDER BY total DESC",
          f.args.toArray());
    }
  }
}
