package pe.edu.solucionesweb.tramite.service;

import java.sql.*;
import java.util.*;
import pe.edu.solucionesweb.tramite.model.Usuario;
import pe.edu.solucionesweb.tramite.util.*;

public final class Relations {
  private Relations() {}

  public static void active(Connection c, String table, long id, Long old) throws SQLException {
    if (!Set.of("areas", "tipos_tramite").contains(table))
      throw new IllegalArgumentException("Catálogo inválido");
    Map<String, Object> row = Sql.one(c, "SELECT * FROM " + table + " WHERE id=? FOR SHARE", id);
    if (row == null || (!Sql.active(row.get("activo")) && !Objects.equals(id, old)))
      throw new IllegalArgumentException("La selección no existe o está inactiva.");
  }

  public static void area(Connection c, Usuario u, long id, Long old) throws SQLException {
    active(c, "areas", id, old);
    if (u.isFuncionario() && !Objects.equals(id, u.getAreaId()))
      throw new SecurityException("Debe registrar en su área asignada.");
  }

  public static void citizen(Connection c, Long id, String dni, Long old) throws SQLException {
    if (id == null) return;
    Map<String, Object> r = Sql.one(c, "SELECT * FROM usuarios WHERE id=? FOR SHARE", id);
    if (r == null
        || !"CIUDADANO".equals(r.get("rol"))
        || (!Sql.active(r.get("activo")) && !Objects.equals(id, old)))
      throw new IllegalArgumentException("Ciudadano inválido o inactivo.");
    if (!dni.equals(r.get("dni")))
      throw new IllegalArgumentException(
          "El DNI del solicitante debe coincidir con el ciudadano seleccionado.");
  }

  public static void document(Connection c, Usuario u, Long id, Long old) throws SQLException {
    if (id == null) return;
    Map<String, Object> d = Sql.one(c, "SELECT * FROM documentos WHERE id=? FOR SHARE", id);
    Access.document(u, d);
    if ("ANULADO".equals(d.get("estado")) && !Objects.equals(id, old))
      throw new IllegalArgumentException("No puede vincular un documento anulado.");
  }
}
