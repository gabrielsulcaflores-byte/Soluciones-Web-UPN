package pe.edu.solucionesweb.tramite.controller;

import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import java.util.*;
import pe.edu.solucionesweb.tramite.dao.*;
import pe.edu.solucionesweb.tramite.model.*;
import pe.edu.solucionesweb.tramite.service.*;
import pe.edu.solucionesweb.tramite.util.*;

@WebServlet("/tramites")
public class TramiteServlet extends BaseServlet {
  private final TramiteDAO dao = new TramiteDAO();

  protected void get(HttpServletRequest r, HttpServletResponse s) throws Exception {
    String action = p(r, "accion");
    if (action.equals("nuevo") || action.equals("editar")) {
      Access.staff(user(r));
      Map<String, Object> v = new HashMap<>();
      v.put("estado", "PENDIENTE");
      if (action.equals("editar")) {
        Tramite t = dao.obtener(id(r));
        Access.tramite(user(r), t == null ? null : t.toMap());
        v = t.toMap();
        if ("CONCLUIDO".equals(t.getEstado()))
          throw new IllegalArgumentException("Un trámite concluido no puede editarse.");
      }
      List<FormField> f = new ArrayList<>();
      f.add(
          select(
              "tipo_id",
              "Tipo de trámite",
              true,
              new TipoTramiteDAO()
                  .opciones(v.get("tipo_id") == null ? null : Sql.number(v.get("tipo_id")))));
      f.add(field("solicitante", "Nombre del solicitante", "text", true, 180));
      f.add(field("identificacion", "DNI o RUC del solicitante", "text", true, 11));
      List<Map<String, Object>> citizens = new ArrayList<>(new UsuarioDAO().ciudadanos());
      if (v.get("ciudadano_id") != null) {
        long cid = Sql.number(v.get("ciudadano_id"));
        if (citizens.stream().noneMatch(x -> Sql.number(x.get("id")) == cid)) {
          Usuario cu = new UsuarioDAO().obtener(cid);
          if (cu != null)
            citizens.add(Map.of("id", cid, "nombre", cu.getNombreCompleto() + " (inactivo)"));
        }
      }
      f.add(
          select("ciudadano_id", "Cuenta del ciudadano (para consulta privada)", false, citizens));
      f.add(
          select(
              "documento_id",
              "Documento relacionado (opcional)",
              false,
              new DocumentoDAO()
                  .opciones(
                      user(r),
                      v.get("documento_id") == null ? null : Sql.number(v.get("documento_id")))));
      f.add(field("asunto", "Asunto", "text", true, 200));
      f.add(field("descripcion", "Descripción", "textarea", true, 5000));
      if (action.equals("nuevo"))
        f.add(
            select(
                "area_id",
                "Área responsable",
                true,
                user(r).isAdmin()
                    ? new AreaDAO().opciones(null)
                    : new AreaDAO()
                        .opciones(user(r).getAreaId()).stream()
                            .filter(x -> Sql.number(x.get("id")) == user(r).getAreaId())
                            .toList()));
      else {
        String state = v.get("estado").toString();
        String[] states =
            switch (state) {
              case "PENDIENTE" -> new String[] {"PENDIENTE", "EN_PROCESO"};
              case "DERIVADO" -> new String[] {"DERIVADO", "EN_PROCESO"};
              case "EN_PROCESO" -> new String[] {"EN_PROCESO", "ATENDIDO"};
              case "ATENDIDO" -> new String[] {"ATENDIDO", "CONCLUIDO"};
              default -> new String[] {state};
            };
        f.add(select("estado", "Estado de atención", true, choices(states)));
      }
      form(r, s, "Trámites", v, f);
    } else {
      filterOptions(r, false);
      r.setAttribute("titulo", user(r).isCiudadano() ? "Mis trámites" : "Trámites");
      r.setAttribute("filas", dao.listar(user(r), filters(r), 200));
      r.setAttribute(
          "columnas",
          Map.of(
              "codigo",
              "Código",
              "solicitante",
              "Solicitante",
              "asunto",
              "Asunto",
              "tipo",
              "Tipo",
              "area",
              "Área",
              "estado",
              "Estado"));
      r.setAttribute("orden", List.of("codigo", "solicitante", "asunto", "tipo", "area", "estado"));
      r.setAttribute("filtros", true);
      r.setAttribute("esTramite", true);
      view(r, s, "list");
    }
  }

  protected void post(HttpServletRequest r, HttpServletResponse s) throws Exception {
    Access.staff(user(r));
    Tramite t = new Tramite();
    t.setId(optional(r, "id"));
    t.setVersion(t.getId() == null ? 0 : Long.parseLong(p(r, "version")));
    t.setTipoId(Validation.id(p(r, "tipo_id")));
    t.setSolicitante(text(r, "solicitante", "Solicitante", 180));
    t.setIdentificacion(Validation.identification(p(r, "identificacion")));
    t.setCiudadanoId(optional(r, "ciudadano_id"));
    t.setDocumentoId(optional(r, "documento_id"));
    t.setAsunto(text(r, "asunto", "Asunto", 200));
    t.setDescripcion(text(r, "descripcion", "Descripción", 5000));
    t.setAreaId(Validation.id(p(r, "area_id")));
    t.setEstado(
        t.getId() == null
            ? "PENDIENTE"
            : Validation.choice(
                p(r, "estado"), "PENDIENTE", "EN_PROCESO", "DERIVADO", "ATENDIDO", "CONCLUIDO"));
    long id = new TramiteService().guardar(user(r), t);
    success(r, s, "/historial?id=" + id, "Trámite guardado; su historial ha sido actualizado.");
  }
}
