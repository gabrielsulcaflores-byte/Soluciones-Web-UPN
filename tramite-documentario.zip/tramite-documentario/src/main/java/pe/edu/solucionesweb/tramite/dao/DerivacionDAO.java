package pe.edu.solucionesweb.tramite.dao;

import java.sql.*;
import java.util.*;
import pe.edu.solucionesweb.tramite.model.Derivacion;
import pe.edu.solucionesweb.tramite.util.*;

public class DerivacionDAO {
  public void registrar(Connection c, Derivacion d) throws SQLException {
    Sql.insert(
        c,
        "INSERT INTO derivaciones(tramite_id,area_origen_id,area_destino_id,usuario_id,observacion)"
            + " VALUES(?,?,?,?,?)",
        d.getTramiteId(),
        d.getAreaOrigenId(),
        d.getAreaDestinoId(),
        d.getUsuarioId(),
        d.getObservacion());
  }

  public List<Map<String, Object>> listar(long id) throws SQLException {
    try (Connection c = Database.open()) {
      return Sql.query(
          c,
          "SELECT d.fecha,a.nombre origen,b.nombre destino,d.observacion,CONCAT(u.nombres,'"
              + " ',u.apellido_paterno) responsable FROM derivaciones d JOIN areas a ON"
              + " a.id=d.area_origen_id JOIN areas b ON b.id=d.area_destino_id JOIN usuarios u ON"
              + " u.id=d.usuario_id WHERE d.tramite_id=? ORDER BY d.fecha,d.id",
          id);
    }
  }
}
