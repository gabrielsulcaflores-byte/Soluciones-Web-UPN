package pe.edu.solucionesweb.tramite.model;

import java.util.*;
import pe.edu.solucionesweb.tramite.util.Sql;

public class Usuario {
  private Long id;

  public Long getId() {
    return id;
  }

  public void setId(Long value) {
    id = value;
  }

  private String nombres;

  public String getNombres() {
    return nombres;
  }

  public void setNombres(String value) {
    nombres = value;
  }

  private String apellidoPaterno;

  public String getApellidoPaterno() {
    return apellidoPaterno;
  }

  public void setApellidoPaterno(String value) {
    apellidoPaterno = value;
  }

  private String apellidoMaterno;

  public String getApellidoMaterno() {
    return apellidoMaterno;
  }

  public void setApellidoMaterno(String value) {
    apellidoMaterno = value;
  }

  private String dni;

  public String getDni() {
    return dni;
  }

  public void setDni(String value) {
    dni = value;
  }

  private String correo;

  public String getCorreo() {
    return correo;
  }

  public void setCorreo(String value) {
    correo = value;
  }

  private String passwordHash;

  public String getPasswordHash() {
    return passwordHash;
  }

  public void setPasswordHash(String value) {
    passwordHash = value;
  }

  private String rol;

  public String getRol() {
    return rol;
  }

  public void setRol(String value) {
    rol = value;
  }

  private Long areaId;

  public Long getAreaId() {
    return areaId;
  }

  public void setAreaId(Long value) {
    areaId = value;
  }

  private Boolean activo;

  public Boolean getActivo() {
    return activo;
  }

  public void setActivo(Boolean value) {
    activo = value;
  }

  public static Usuario from(Map<String, Object> row) {
    if (row == null) return null;
    Usuario b = new Usuario();
    b.id = row.get("id") == null ? null : Sql.number(row.get("id"));
    b.nombres = row.get("nombres") == null ? null : row.get("nombres").toString();
    b.apellidoPaterno =
        row.get("apellido_paterno") == null ? null : row.get("apellido_paterno").toString();
    b.apellidoMaterno =
        row.get("apellido_materno") == null ? null : row.get("apellido_materno").toString();
    b.dni = row.get("dni") == null ? null : row.get("dni").toString();
    b.correo = row.get("correo") == null ? null : row.get("correo").toString();
    b.passwordHash = row.get("password_hash") == null ? null : row.get("password_hash").toString();
    b.rol = row.get("rol") == null ? null : row.get("rol").toString();
    b.areaId = row.get("area_id") == null ? null : Sql.number(row.get("area_id"));
    b.activo = Sql.active(row.get("activo"));
    return b;
  }

  public Map<String, Object> toMap() {
    Map<String, Object> m = new LinkedHashMap<>();
    m.put("id", id);
    m.put("nombres", nombres);
    m.put("apellido_paterno", apellidoPaterno);
    m.put("apellido_materno", apellidoMaterno);
    m.put("dni", dni);
    m.put("correo", correo);
    m.put("rol", rol);
    m.put("area_id", areaId);
    m.put("activo", activo);
    return m;
  }

  public String getNombreCompleto() {
    return nombres + " " + apellidoPaterno + " " + apellidoMaterno;
  }

  public boolean isAdmin() {
    return "ADMINISTRADOR".equals(rol);
  }

  public boolean isFuncionario() {
    return "FUNCIONARIO".equals(rol);
  }

  public boolean isCiudadano() {
    return "CIUDADANO".equals(rol);
  }
}
