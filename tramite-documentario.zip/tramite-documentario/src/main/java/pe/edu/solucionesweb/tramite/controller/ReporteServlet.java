package pe.edu.solucionesweb.tramite.controller;

import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import java.util.*;
import pe.edu.solucionesweb.tramite.dao.*;

@WebServlet("/reportes")
public class ReporteServlet extends BaseServlet {
  protected void get(HttpServletRequest r, HttpServletResponse s) throws Exception {
    var rows = new TramiteDAO().listar(user(r), filters(r), 0);
    if (p(r, "exportar").equals("csv")) {
      s.setContentType("text/csv;charset=UTF-8");
      s.setHeader("Content-Disposition", "attachment; filename=tramites.csv");
      var out = s.getWriter();
      out.print("\ufeff");
      out.println("Código;Solicitante;Asunto;Tipo;Área;Estado;Fecha");
      for (var row : rows) {
        List<String> cells = new ArrayList<>();
        for (String k :
            List.of("codigo", "solicitante", "asunto", "tipo", "area", "estado", "fecha_registro"))
          cells.add(csv(Objects.toString(row.get(k), "")));
        out.println(String.join(";", cells));
      }
      return;
    }
    filterOptions(r, false);
    r.setAttribute("filas", rows);
    view(r, s, "reports");
  }

  public static String csv(String value) {
    if (value.matches("(?s)^\\s*[=+@-].*")) value = "'" + value;
    return "\"" + value.replace("\"", "\"\"") + "\"";
  }
}
