package pe.edu.solucionesweb.tramite.dao;

import java.sql.*;
import java.util.*;
import pe.edu.solucionesweb.tramite.model.Usuario;
import pe.edu.solucionesweb.tramite.util.*;

public class UsuarioDAO {
  public Usuario obtener(long id) throws SQLException {
    try (Connection c = Database.open()) {
      return Usuario.from(Sql.one(c, "SELECT * FROM usuarios WHERE id=?", id));
    }
  }

  public Usuario buscarCorreo(String correo) throws SQLException {
    try (Connection c = Database.open()) {
      return Usuario.from(Sql.one(c, "SELECT * FROM usuarios WHERE correo=?", correo));
    }
  }

  public List<Map<String, Object>> listar(String q) throws SQLException {
    try (Connection c = Database.open()) {
      return Sql.query(
          c,
          "SELECT u.id,CONCAT(u.nombres,' ',u.apellido_paterno,' ',u.apellido_materno)"
              + " nombre,u.dni,u.correo,u.rol,a.nombre area,u.activo FROM usuarios u LEFT JOIN"
              + " areas a ON a.id=u.area_id WHERE CONCAT(u.nombres,' ',u.apellido_paterno,'"
              + " ',u.dni,' ',u.correo) LIKE ? ORDER BY u.id DESC LIMIT 200",
          "%" + q + "%");
    }
  }

  public List<Map<String, Object>> ciudadanos() throws SQLException {
    try (Connection c = Database.open()) {
      return Sql.query(
          c,
          "SELECT id,CONCAT(nombres,' ',apellido_paterno,' · ',dni) nombre FROM usuarios WHERE"
              + " activo=1 AND rol='CIUDADANO' ORDER BY nombres");
    }
  }

  public long registrar(Connection c, Usuario u) throws SQLException {
    return Sql.insert(
        c,
        "INSERT INTO"
            + " usuarios(nombres,apellido_paterno,apellido_materno,dni,correo,password_hash,rol,area_id)"
            + " VALUES(?,?,?,?,?,?,?,?)",
        u.getNombres(),
        u.getApellidoPaterno(),
        u.getApellidoMaterno(),
        u.getDni(),
        u.getCorreo(),
        u.getPasswordHash(),
        u.getRol(),
        u.getAreaId());
  }

  public void actualizar(Connection c, Usuario u) throws SQLException {
    Sql.update(
        c,
        "UPDATE usuarios SET"
            + " nombres=?,apellido_paterno=?,apellido_materno=?,dni=?,correo=?,rol=?,area_id=?"
            + " WHERE id=?",
        u.getNombres(),
        u.getApellidoPaterno(),
        u.getApellidoMaterno(),
        u.getDni(),
        u.getCorreo(),
        u.getRol(),
        u.getAreaId(),
        u.getId());
    if (u.getPasswordHash() != null)
      Sql.update(
          c, "UPDATE usuarios SET password_hash=? WHERE id=?", u.getPasswordHash(), u.getId());
  }
}
