package pe.edu.solucionesweb.tramite.controller;

import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import java.util.*;
import pe.edu.solucionesweb.tramite.dao.*;
import pe.edu.solucionesweb.tramite.model.*;
import pe.edu.solucionesweb.tramite.service.*;

@WebServlet("/tipos")
public class TipoTramiteServlet extends BaseServlet {
  private final TipoTramiteDAO dao = new TipoTramiteDAO();

  protected void get(HttpServletRequest r, HttpServletResponse s) throws Exception {
    Access.admin(user(r));
    String action = p(r, "accion");
    if (action.equals("nuevo") || action.equals("editar")) {
      Map<String, Object> v = new HashMap<>();
      if (action.equals("editar")) {
        TipoTramite b = dao.obtener(id(r));
        if (b == null) throw new IllegalArgumentException("Registro no encontrado.");
        v = b.toMap();
      }
      form(
          r,
          s,
          "Tipos de trámite",
          v,
          List.of(
              field("nombre", "Nombre", "text", true, 100),
              field("descripcion", "Descripción", "textarea", true, 500)));
    } else {
      r.setAttribute("titulo", "Tipos de trámite");
      r.setAttribute("filas", dao.listar(p(r, "q")));
      r.setAttribute(
          "columnas", Map.of("nombre", "Nombre", "descripcion", "Descripción", "activo", "Activo"));
      r.setAttribute("orden", List.of("nombre", "descripcion", "activo"));
      r.setAttribute("catalogo", true);
      view(r, s, "list");
    }
  }

  protected void post(HttpServletRequest r, HttpServletResponse s) throws Exception {
    Access.admin(user(r));
    if (p(r, "accion").equals("estado")) {
      dao.estado(id(r), p(r, "activo").equals("true"));
    } else {
      TipoTramite b = new TipoTramite();
      b.setId(optional(r, "id"));
      b.setNombre(text(r, "nombre", "Nombre", 100));
      b.setDescripcion(text(r, "descripcion", "Descripción", 500));
      dao.guardar(b);
    }
    success(r, s, "/tipos", "Operación completada. Los registros históricos se conservan.");
  }
}
