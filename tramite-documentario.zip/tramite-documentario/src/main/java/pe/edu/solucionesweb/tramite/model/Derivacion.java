package pe.edu.solucionesweb.tramite.model;

import java.util.*;
import pe.edu.solucionesweb.tramite.util.Sql;

public class Derivacion {
  private Long id;

  public Long getId() {
    return id;
  }

  public void setId(Long value) {
    id = value;
  }

  private Long tramiteId;

  public Long getTramiteId() {
    return tramiteId;
  }

  public void setTramiteId(Long value) {
    tramiteId = value;
  }

  private Long areaOrigenId;

  public Long getAreaOrigenId() {
    return areaOrigenId;
  }

  public void setAreaOrigenId(Long value) {
    areaOrigenId = value;
  }

  private Long areaDestinoId;

  public Long getAreaDestinoId() {
    return areaDestinoId;
  }

  public void setAreaDestinoId(Long value) {
    areaDestinoId = value;
  }

  private Long usuarioId;

  public Long getUsuarioId() {
    return usuarioId;
  }

  public void setUsuarioId(Long value) {
    usuarioId = value;
  }

  private String fecha;

  public String getFecha() {
    return fecha;
  }

  public void setFecha(String value) {
    fecha = value;
  }

  private String observacion;

  public String getObservacion() {
    return observacion;
  }

  public void setObservacion(String value) {
    observacion = value;
  }

  public static Derivacion from(Map<String, Object> row) {
    if (row == null) return null;
    Derivacion b = new Derivacion();
    b.id = row.get("id") == null ? null : Sql.number(row.get("id"));
    b.tramiteId = row.get("tramite_id") == null ? null : Sql.number(row.get("tramite_id"));
    b.areaOrigenId =
        row.get("area_origen_id") == null ? null : Sql.number(row.get("area_origen_id"));
    b.areaDestinoId =
        row.get("area_destino_id") == null ? null : Sql.number(row.get("area_destino_id"));
    b.usuarioId = row.get("usuario_id") == null ? null : Sql.number(row.get("usuario_id"));
    b.fecha = row.get("fecha") == null ? null : row.get("fecha").toString();
    b.observacion = row.get("observacion") == null ? null : row.get("observacion").toString();
    return b;
  }

  public Map<String, Object> toMap() {
    Map<String, Object> m = new LinkedHashMap<>();
    m.put("id", id);
    m.put("tramite_id", tramiteId);
    m.put("area_origen_id", areaOrigenId);
    m.put("area_destino_id", areaDestinoId);
    m.put("usuario_id", usuarioId);
    m.put("fecha", fecha);
    m.put("observacion", observacion);
    return m;
  }
}
