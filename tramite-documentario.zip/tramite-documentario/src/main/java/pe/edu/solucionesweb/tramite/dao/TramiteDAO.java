package pe.edu.solucionesweb.tramite.dao;

import java.sql.*;
import java.util.*;
import pe.edu.solucionesweb.tramite.model.*;
import pe.edu.solucionesweb.tramite.util.*;

public class TramiteDAO implements TramiteRepository {
  public Tramite obtener(long id) throws SQLException {
    try (Connection c = Database.open()) {
      return Tramite.from(Sql.one(c, "SELECT * FROM tramites WHERE id=?", id));
    }
  }

  public Map<String, Object> detalle(long id) throws SQLException {
    try (Connection c = Database.open()) {
      return Sql.one(
          c,
          "SELECT t.*,a.nombre area,tp.nombre tipo,CONCAT(u.nombres,' ',u.apellido_paterno)"
              + " registrado_por,d.codigo documento FROM tramites t JOIN areas a ON a.id=t.area_id"
              + " JOIN tipos_tramite tp ON tp.id=t.tipo_id JOIN usuarios u ON u.id=t.usuario_id"
              + " LEFT JOIN documentos d ON d.id=t.documento_id WHERE t.id=?",
          id);
    }
  }

  public List<Map<String, Object>> listar(Usuario u, FiltroConsulta f, int limit)
      throws SQLException {
    try (Connection c = Database.open()) {
      String where = f.where(u, false);
      return Sql.query(
          c,
          "SELECT t.*,a.nombre area,tp.nombre tipo FROM tramites t JOIN areas a ON a.id=t.area_id"
              + " JOIN tipos_tramite tp ON tp.id=t.tipo_id"
              + where
              + " ORDER BY t.id DESC LIMIT "
              + (limit == 0 ? "10000" : Math.min(limit, 200)),
          f.args.toArray());
    }
  }

  public Map<String, Object> bloquear(Connection c, long id) throws SQLException {
    return Sql.one(c, "SELECT * FROM tramites WHERE id=? FOR UPDATE", id);
  }

  public long registrar(Connection c, Tramite t) throws SQLException {
    return Sql.insert(
        c,
        "INSERT INTO"
            + " tramites(codigo,tipo_id,solicitante,identificacion,ciudadano_id,documento_id,asunto,descripcion,area_id,usuario_id)"
            + " VALUES(?,?,?,?,?,?,?,?,?,?)",
        t.getCodigo(),
        t.getTipoId(),
        t.getSolicitante(),
        t.getIdentificacion(),
        t.getCiudadanoId(),
        t.getDocumentoId(),
        t.getAsunto(),
        t.getDescripcion(),
        t.getAreaId(),
        t.getUsuarioId());
  }

  public void actualizar(Connection c, Tramite t) throws SQLException {
    int n =
        Sql.update(
            c,
            "UPDATE tramites SET"
                + " tipo_id=?,solicitante=?,identificacion=?,ciudadano_id=?,documento_id=?,asunto=?,descripcion=?,estado=?,version=version+1"
                + " WHERE id=? AND version=?",
            t.getTipoId(),
            t.getSolicitante(),
            t.getIdentificacion(),
            t.getCiudadanoId(),
            t.getDocumentoId(),
            t.getAsunto(),
            t.getDescripcion(),
            t.getEstado(),
            t.getId(),
            t.getVersion());
    if (n != 1) throw new IllegalArgumentException("El trámite cambió. Recargue antes de guardar.");
  }

  public void cambiarArea(Connection c, long id, long area) throws SQLException {
    Sql.update(
        c,
        "UPDATE tramites SET area_id=?,estado='DERIVADO',version=version+1 WHERE id=?",
        area,
        id);
  }
}
