package pe.edu.solucionesweb.tramite.controller;

import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import java.util.*;
import pe.edu.solucionesweb.tramite.dao.*;
import pe.edu.solucionesweb.tramite.model.*;
import pe.edu.solucionesweb.tramite.util.*;

@WebServlet("/login")
public class LoginServlet extends BaseServlet {
  private static final String DUMMY = Password.hash("Credencial ficticia para comparación");

  protected void get(HttpServletRequest r, HttpServletResponse s) throws Exception {
    if (user(r) != null) s.sendRedirect(r.getContextPath() + "/dashboard");
    else view(r, s, "login");
  }

  protected void post(HttpServletRequest r, HttpServletResponse s) throws Exception {
    HttpSession session = r.getSession();
    Long until = (Long) session.getAttribute("loginUntil");
    if (until != null && until > System.currentTimeMillis()) {
      r.setAttribute("error", "Espere un minuto antes de volver a intentarlo.");
      s.setStatus(429);
      view(r, s, "login");
      return;
    }
    String correo = Validation.email(p(r, "correo"));
    String password = r.getParameter("password");
    if (password == null || password.length() > 128)
      throw new IllegalArgumentException("Credenciales inválidas.");
    Usuario u = new UsuarioDAO().buscarCorreo(correo);
    boolean valid = Password.verify(password, u == null ? DUMMY : u.getPasswordHash());
    if (u == null || !Boolean.TRUE.equals(u.getActivo()) || !valid) {
      int fails =
          ((Number) Objects.requireNonNullElse(session.getAttribute("fails"), 0)).intValue() + 1;
      session.setAttribute("fails", fails);
      if (fails >= 5) {
        session.setAttribute("loginUntil", System.currentTimeMillis() + 60000);
        session.setAttribute("fails", 0);
      }
      r.setAttribute("error", "Correo o contraseña incorrectos, o cuenta inactiva.");
      s.setStatus(401);
      view(r, s, "login");
      return;
    }
    r.changeSessionId();
    session.removeAttribute("fails");
    session.removeAttribute("loginUntil");
    u.setPasswordHash(null);
    session.setAttribute("usuario", u);
    session.setAttribute("csrf", UUID.randomUUID().toString());
    s.sendRedirect(r.getContextPath() + "/dashboard");
  }
}
