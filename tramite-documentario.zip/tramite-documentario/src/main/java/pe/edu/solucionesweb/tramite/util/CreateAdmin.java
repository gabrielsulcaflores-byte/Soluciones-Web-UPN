package pe.edu.solucionesweb.tramite.util;

import java.io.Console;
import java.sql.*;

/**
 * Ejecutar con classpath de target/classes y Connector/J; solicita datos sin imprimir contraseña.
 */
public class CreateAdmin {
  public static void main(String[] args) throws Exception {
    Console c = System.console();
    if (c == null) throw new IllegalStateException("Ejecute desde una terminal interactiva.");
    String email = Validation.email(c.readLine("Correo: "));
    String dni = Validation.dni(c.readLine("DNI: "));
    String name = Validation.text(c.readLine("Nombres: "), "Nombres", 100);
    String father = Validation.text(c.readLine("Apellido paterno: "), "Apellido paterno", 80);
    String mother = Validation.text(c.readLine("Apellido materno: "), "Apellido materno", 80);
    char[] chars = c.readPassword("Contraseña (12-128 caracteres): ");
    String password = new String(chars);
    java.util.Arrays.fill(chars, '\0');
    Validation.password(password);
    try (Connection db = Database.open()) {
      Sql.insert(
          db,
          "INSERT INTO"
              + " usuarios(nombres,apellido_paterno,apellido_materno,dni,correo,password_hash,rol)"
              + " VALUES(?,?,?,?,?,?,'ADMINISTRADOR')",
          name,
          father,
          mother,
          dni,
          email,
          Password.hash(password));
    }
    c.printf("Administrador creado correctamente.%n");
  }
}
