package pe.edu.solucionesweb.tramite.service;

import java.sql.*;
import java.util.*;
import pe.edu.solucionesweb.tramite.dao.UsuarioDAO;
import pe.edu.solucionesweb.tramite.model.Usuario;
import pe.edu.solucionesweb.tramite.util.*;

public class UsuarioService {
  private final UsuarioDAO dao = new UsuarioDAO();

  public void guardar(Usuario actor, Usuario u) throws SQLException {
    Access.admin(actor);
    try (Connection c = Database.open()) {
      c.setAutoCommit(false);
      try {
        // Serializa las modificaciones administrativas para conservar al menos un administrador
        // activo.
        Sql.query(
            c,
            "SELECT id FROM usuarios WHERE rol='ADMINISTRADOR' AND activo=1 ORDER BY id FOR"
                + " UPDATE");
        Map<String, Object> old =
            u.getId() == null
                ? null
                : Sql.one(c, "SELECT * FROM usuarios WHERE id=? FOR UPDATE", u.getId());
        if (u.getId() != null && old == null)
          throw new IllegalArgumentException("Usuario no encontrado.");
        if (old != null
            && "CIUDADANO".equals(old.get("rol"))
            && (!"CIUDADANO".equals(u.getRol()) || !Objects.equals(old.get("dni"), u.getDni()))
            && Sql.one(c, "SELECT id FROM tramites WHERE ciudadano_id=? LIMIT 1", u.getId())
                != null)
          throw new IllegalArgumentException(
              "No cambie rol o DNI de un ciudadano con trámites vinculados.");
        if (u.getId() != null
            && u.getId().equals(actor.getId())
            && !"ADMINISTRADOR".equals(u.getRol()))
          throw new IllegalArgumentException("No puede quitarse su propio rol administrador.");
        if ("FUNCIONARIO".equals(u.getRol())) {
          if (u.getAreaId() == null)
            throw new IllegalArgumentException("Seleccione el área del funcionario.");
          Relations.active(
              c,
              "areas",
              u.getAreaId(),
              old == null
                  ? null
                  : old.get("area_id") == null ? null : Sql.number(old.get("area_id")));
        } else u.setAreaId(null);
        if (old != null
            && "ADMINISTRADOR".equals(old.get("rol"))
            && !"ADMINISTRADOR".equals(u.getRol())) lastAdmin(c);
        if (old == null) dao.registrar(c, u);
        else dao.actualizar(c, u);
        c.commit();
      } catch (SQLException | RuntimeException e) {
        c.rollback();
        throw e;
      }
    }
  }

  public void estado(Usuario actor, long id, boolean activo) throws SQLException {
    Access.admin(actor);
    if (actor.getId() == id && !activo)
      throw new IllegalArgumentException("No puede desactivar su propia cuenta.");
    try (Connection c = Database.open()) {
      c.setAutoCommit(false);
      try {
        Sql.query(
            c,
            "SELECT id FROM usuarios WHERE rol='ADMINISTRADOR' AND activo=1 ORDER BY id FOR"
                + " UPDATE");
        Map<String, Object> old = Sql.one(c, "SELECT * FROM usuarios WHERE id=? FOR UPDATE", id);
        if (old == null) throw new IllegalArgumentException("Usuario no encontrado.");
        if (!activo && Sql.active(old.get("activo")) && "ADMINISTRADOR".equals(old.get("rol")))
          lastAdmin(c);
        Sql.update(c, "UPDATE usuarios SET activo=? WHERE id=?", activo, id);
        c.commit();
      } catch (SQLException | RuntimeException e) {
        c.rollback();
        throw e;
      }
    }
  }

  private void lastAdmin(Connection c) throws SQLException {
    if (Sql.number(
            Sql.one(c, "SELECT COUNT(*) n FROM usuarios WHERE rol='ADMINISTRADOR' AND activo=1")
                .get("n"))
        <= 1) throw new IllegalArgumentException("Debe conservar un administrador activo.");
  }
}
