"use strict";
document.querySelectorAll("form[data-confirm]").forEach((form) =>
  form.addEventListener("submit", (e) => {
    if (!window.confirm(form.dataset.confirm)) e.preventDefault();
  }),
);
document.querySelectorAll("form[data-document-form]").forEach((form) =>
  form.addEventListener("submit", (e) => {
    if (
      form.elements.estado.value === "ANULADO" &&
      !window.confirm(
        "¿Anular este documento? Se conservará y quedará sin edición.",
      )
    )
      e.preventDefault();
  }),
);
document.querySelector("#menu-toggle")?.addEventListener("click", (e) => {
  const open = document.querySelector(".sidebar").classList.toggle("open");
  e.currentTarget.setAttribute("aria-expanded", String(open));
});
document
  .querySelector("#print-report")
  ?.addEventListener("click", () => window.print());
document
  .querySelector("#go-back")
  ?.addEventListener("click", () => window.history.back());
const role = document.querySelector("#rol"),
  area = document.querySelector("#area_id");
if (role && area) {
  const update = () => {
    area.required = role.value === "FUNCIONARIO";
    area.closest(".field").hidden = role.value !== "FUNCIONARIO";
  };
  role.addEventListener("change", update);
  update();
}
const search = document.querySelector("#tramite-search");
if (search) {
  let timer,
    request,
    revision = 0;
  const output = document.querySelector("#search-results"),
    status = document.querySelector("#search-status");
  search.addEventListener("input", () => {
    clearTimeout(timer);
    revision++;
    if (request) request.abort();
    output.replaceChildren();
    const term = search.value.trim();
    if (term.length < 2) {
      status.textContent = "Escribe al menos 2 caracteres.";
      return;
    }
    status.textContent = "Buscando…";
    const current = revision;
    timer = setTimeout(() => {
      request = new XMLHttpRequest();
      request.open(
        "GET",
        search.dataset.endpoint + "?q=" + encodeURIComponent(term),
      );
      request.timeout = 10000;
      request.onload = () => {
        if (current !== revision) return;
        const xml = request.responseXML;
        if (
          request.status !== 200 ||
          !xml ||
          xml.querySelector("parsererror")
        ) {
          status.textContent =
            "No se pudo consultar. Revise su sesión y vuelva a intentar.";
          return;
        }
        const rows = xml.querySelectorAll("tramite");
        status.textContent = rows.length
          ? rows.length + " resultados (máximo 20)."
          : "No se encontraron trámites.";
        rows.forEach((row) => {
          const a = document.createElement("a");
          a.href =
            search.dataset.target +
            "?id=" +
            encodeURIComponent(row.querySelector("id").textContent);
          a.textContent =
            row.querySelector("codigo").textContent +
            " · " +
            row.querySelector("asunto").textContent +
            " · " +
            row.querySelector("area").textContent;
          output.append(a);
        });
      };
      request.onerror = request.ontimeout = () => {
        status.textContent = "Error de conexión. Vuelva a intentar.";
      };
      request.send();
    }, 300);
  });
}
