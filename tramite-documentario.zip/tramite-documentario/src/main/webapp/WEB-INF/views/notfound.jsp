<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<%@ taglib prefix="fn" uri="jakarta.tags.functions" %>

<%@ include file="header.jspf" %><section class="surface error-card"><div class="error-symbol">404</div><span class="eyebrow">PLATAFORMA DOCUMENTARIA</span><h1>Página no encontrada</h1><p><c:out value="${empty error ? '${msg}' : error}"/></p><button class="btn btn-light" id="go-back" type="button">Volver</button><a class="btn btn-primary" href="${pageContext.request.contextPath}/${empty sessionScope.usuario ? 'login' : 'dashboard'}">${empty sessionScope.usuario ? 'Iniciar sesión' : 'Ir al panel'}</a></section><%@ include file="footer.jspf" %>
