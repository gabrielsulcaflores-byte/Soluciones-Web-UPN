-- SOLO demostración local, importar después del esquema. Contraseña de las tres cuentas: DemoOlivos!2026
USE tramite_documentario;
INSERT INTO usuarios(nombres,apellido_paterno,apellido_materno,dni,correo,password_hash,rol,area_id) VALUES
('Ana','Administrador','Demo','10000001','admin@demo.local','pbkdf2$600000$W95QyemgkGRZwlscpv6JsA==$RUkbWP7AWDFjQvmPivnDxzgs57cnP/wwV6VFFyHgDl0=','ADMINISTRADOR',NULL),
('Luis','Funcionario','Demo','10000002','funcionario@demo.local','pbkdf2$600000$ctMXdZ03yahvhLOufMFnDQ==$yQ5N6KLOIRoI47uaJiIUIA/sZKBmf+Wr86STaolp0qA=','FUNCIONARIO',1),
('María','Ciudadano','Demo','10000003','ciudadano@demo.local','pbkdf2$600000$5Yh8ZyglvZrSVF05R8c1zA==$LWLjoz41yEgWzOArXDAs2WW2Qf0meQzVFoeFMn+gRUo=','CIUDADANO',NULL);
INSERT INTO documentos(codigo,tipo_documento,remitente,identificacion,asunto,descripcion,fecha_recepcion,area_id,usuario_id)
VALUES('DOC-DEMO-001','Solicitud','María Ciudadano Demo','10000003','Solicitud de orientación','Documento de prueba académica',CURRENT_DATE,1,1);
INSERT INTO tramites(codigo,tipo_id,solicitante,identificacion,ciudadano_id,documento_id,asunto,descripcion,area_id,usuario_id)
VALUES('TRA-DEMO-001',1,'María Ciudadano Demo','10000003',3,1,'Orientación municipal','Expediente de prueba académica',1,1);
INSERT INTO historial_tramites(tramite_id,usuario_id,accion,descripcion) VALUES(1,1,'REGISTRO','Registro inicial de demostración');
