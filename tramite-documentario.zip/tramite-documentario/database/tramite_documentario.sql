-- Esquema académico. No elimina bases ni tablas existentes. MySQL 8.0.16+.
CREATE DATABASE IF NOT EXISTS tramite_documentario CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci;
USE tramite_documentario;
CREATE TABLE areas (
 id BIGINT PRIMARY KEY AUTO_INCREMENT, nombre VARCHAR(120) NOT NULL UNIQUE,
 descripcion VARCHAR(500) NOT NULL, activo BOOLEAN NOT NULL DEFAULT TRUE
);
CREATE TABLE tipos_tramite (
 id BIGINT PRIMARY KEY AUTO_INCREMENT, nombre VARCHAR(100) NOT NULL UNIQUE,
 descripcion VARCHAR(500) NOT NULL, activo BOOLEAN NOT NULL DEFAULT TRUE
);
CREATE TABLE usuarios (
 id BIGINT PRIMARY KEY AUTO_INCREMENT, nombres VARCHAR(100) NOT NULL,
 apellido_paterno VARCHAR(80) NOT NULL, apellido_materno VARCHAR(80) NOT NULL,
 dni CHAR(8) NOT NULL UNIQUE, correo VARCHAR(160) NOT NULL UNIQUE,
 password_hash VARCHAR(300) NOT NULL, rol ENUM('ADMINISTRADOR','FUNCIONARIO','CIUDADANO') NOT NULL,
 area_id BIGINT NULL, activo BOOLEAN NOT NULL DEFAULT TRUE,
 CONSTRAINT fk_usuario_area FOREIGN KEY(area_id) REFERENCES areas(id) ON DELETE RESTRICT,
 CONSTRAINT ck_dni CHECK (dni REGEXP '^[0-9]{8}$'),
 CONSTRAINT ck_funcionario_area CHECK (rol <> 'FUNCIONARIO' OR area_id IS NOT NULL)
);
CREATE TABLE documentos (
 id BIGINT PRIMARY KEY AUTO_INCREMENT, codigo VARCHAR(40) NOT NULL UNIQUE,
 tipo_documento VARCHAR(60) NOT NULL, remitente VARCHAR(180) NOT NULL, identificacion VARCHAR(11) NOT NULL,
 asunto VARCHAR(200) NOT NULL, descripcion TEXT NOT NULL, fecha_recepcion DATE NOT NULL,
 area_id BIGINT NOT NULL, estado ENUM('RECIBIDO','EN_REVISION','ARCHIVADO','ANULADO') NOT NULL DEFAULT 'RECIBIDO',
 usuario_id BIGINT NOT NULL, version INT NOT NULL DEFAULT 0,
 FOREIGN KEY(area_id) REFERENCES areas(id) ON DELETE RESTRICT,
 FOREIGN KEY(usuario_id) REFERENCES usuarios(id) ON DELETE RESTRICT,
 CONSTRAINT ck_documento_identificacion CHECK (identificacion REGEXP '^([0-9]{8}|[0-9]{11})$'),
 INDEX ix_documentos_filtros (area_id,estado,fecha_recepcion)
);
CREATE TABLE tramites (
 id BIGINT PRIMARY KEY AUTO_INCREMENT, codigo VARCHAR(40) NOT NULL UNIQUE,
 tipo_id BIGINT NOT NULL, solicitante VARCHAR(180) NOT NULL, identificacion VARCHAR(11) NOT NULL,
 ciudadano_id BIGINT NULL, documento_id BIGINT NULL,
 asunto VARCHAR(200) NOT NULL, descripcion TEXT NOT NULL, fecha_registro DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
 area_id BIGINT NOT NULL, estado ENUM('PENDIENTE','EN_PROCESO','DERIVADO','ATENDIDO','CONCLUIDO') NOT NULL DEFAULT 'PENDIENTE',
 usuario_id BIGINT NOT NULL, version INT NOT NULL DEFAULT 0,
 FOREIGN KEY(tipo_id) REFERENCES tipos_tramite(id) ON DELETE RESTRICT,
 FOREIGN KEY(area_id) REFERENCES areas(id) ON DELETE RESTRICT,
 FOREIGN KEY(usuario_id) REFERENCES usuarios(id) ON DELETE RESTRICT,
 FOREIGN KEY(ciudadano_id) REFERENCES usuarios(id) ON DELETE RESTRICT,
 FOREIGN KEY(documento_id) REFERENCES documentos(id) ON DELETE RESTRICT,
 CONSTRAINT ck_tramite_identificacion CHECK (identificacion REGEXP '^([0-9]{8}|[0-9]{11})$'),
 INDEX ix_tramites_filtros(area_id,estado,fecha_registro), INDEX ix_tramites_ciudadano(ciudadano_id), INDEX ix_tramites_tipo(tipo_id)
);
CREATE TABLE derivaciones (
 id BIGINT PRIMARY KEY AUTO_INCREMENT, tramite_id BIGINT NOT NULL,
 area_origen_id BIGINT NOT NULL, area_destino_id BIGINT NOT NULL, usuario_id BIGINT NOT NULL,
 fecha DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP, observacion VARCHAR(1000) NOT NULL,
 FOREIGN KEY(tramite_id) REFERENCES tramites(id) ON DELETE RESTRICT,
 FOREIGN KEY(area_origen_id) REFERENCES areas(id) ON DELETE RESTRICT,
 FOREIGN KEY(area_destino_id) REFERENCES areas(id) ON DELETE RESTRICT,
 FOREIGN KEY(usuario_id) REFERENCES usuarios(id) ON DELETE RESTRICT,
 CHECK (area_origen_id <> area_destino_id), INDEX ix_derivaciones_tramite(tramite_id,fecha)
);
CREATE TABLE historial_tramites (
 id BIGINT PRIMARY KEY AUTO_INCREMENT, tramite_id BIGINT NOT NULL, usuario_id BIGINT NOT NULL,
 fecha DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP, accion VARCHAR(40) NOT NULL, descripcion VARCHAR(1500) NOT NULL,
 FOREIGN KEY(tramite_id) REFERENCES tramites(id) ON DELETE RESTRICT,
 FOREIGN KEY(usuario_id) REFERENCES usuarios(id) ON DELETE RESTRICT,
 INDEX ix_historial_tramite(tramite_id,fecha,id)
);
INSERT INTO areas(nombre,descripcion) VALUES
 ('Mesa de Partes','Recepción y distribución de expedientes'),('Desarrollo Urbano','Permisos y gestión urbana'),
 ('Atención al Ciudadano','Orientación y atención de solicitudes'),('Administración Tributaria','Gestión de asuntos tributarios');
INSERT INTO tipos_tramite(nombre,descripcion) VALUES
 ('Solicitud','Petición formal del ciudadano'),('Queja','Comunicación de disconformidad'),('Permiso','Autorización municipal');
