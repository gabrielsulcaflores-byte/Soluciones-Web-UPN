param([string]$Config = $env:TRAMITE_CONFIG)
$ErrorActionPreference = 'Stop'
$projectRoot = Split-Path $PSScriptRoot -Parent
if (-not $Config) { $Config = Join-Path $projectRoot 'config\database.properties' }
$Config = (Resolve-Path -LiteralPath $Config).Path
& java "-Dtramite.config=$Config" '-cp' "$(Join-Path $projectRoot 'target\classes');$(Join-Path $projectRoot 'target\tramite\WEB-INF\lib\*')" 'pe.edu.solucionesweb.tramite.util.CreateAdmin'
exit $LASTEXITCODE
