param([string]$Config = $env:TRAMITE_CONFIG)
$ErrorActionPreference = 'Stop'
$projectRoot = Split-Path $PSScriptRoot -Parent
if (-not $Config) { $Config = Join-Path $projectRoot 'config\database.properties' }
$Config = (Resolve-Path -LiteralPath $Config).Path
$classes = Join-Path $projectRoot 'target\classes'
$libs = Join-Path $projectRoot 'target\tramite\WEB-INF\lib\*'
& java "-Dtramite.config=$Config" '-cp' "$classes;$libs" 'pe.edu.solucionesweb.tramite.util.CheckDatabase'
exit $LASTEXITCODE
