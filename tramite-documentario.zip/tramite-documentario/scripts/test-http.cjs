/* Pruebas funcionales HTTP. SOLO sobre una base desechable con datos_demo.sql. */
const assert = require("node:assert/strict");
const fs = require("node:fs");
async function run(base) {
  const results = [];
  let cookies = {};
  const clients = {};
  function client(name) {
    const jar = {};
    clients[name] = jar;
    return async (route, form) => {
      const headers = {};
      if (Object.keys(jar).length)
        headers.Cookie = Object.entries(jar)
          .map(([k, v]) => k + "=" + v)
          .join("; ");
      if (form) headers["Content-Type"] = "application/x-www-form-urlencoded";
      const res = await fetch(base + route, {
        redirect: "manual",
        method: form ? "POST" : "GET",
        headers,
        body: form ? new URLSearchParams(form) : undefined,
      });
      for (const cookie of res.headers.getSetCookie()) {
        const pair = cookie.split(";")[0],
          i = pair.indexOf("=");
        jar[pair.slice(0, i)] = pair.slice(i + 1);
      }
      return {
        status: res.status,
        text: await res.text(),
        location: res.headers.get("location"),
        type: res.headers.get("content-type"),
      };
    };
  }
  function csrf(page) {
    const token = page.text.match(/name="csrf" value="([^"]+)"/);
    assert.ok(token, "CSRF presente");
    return token[1];
  }
  function hidden(page, key) {
    return (
      page.text.match(new RegExp('name="' + key + '" value="([^"]*)"'))?.[1] ??
      ""
    );
  }
  async function test(name, fn) {
    try {
      await fn();
      results.push({ name, status: "PASS" });
      console.log("PASS " + name);
    } catch (e) {
      results.push({ name, status: "FAIL", error: e.message });
      console.error("FAIL " + name + " " + e.message);
    }
  }
  const admin = client("admin"),
    staff = client("staff"),
    citizen = client("citizen"),
    anon = client("anon");
  async function login(c, email) {
    const page = await c("/login");
    assert.equal(page.status, 200);
    const res = await c("/login", {
      csrf: csrf(page),
      correo: email,
      password: "DemoOlivos!2026",
    });
    assert.equal(res.status, 302, res.text.slice(-1000));
  }
  const userForm = {
    nombres: "Pedro",
    apellido_paterno: "Prueba",
    apellido_materno: "Académica",
    dni: "40000001",
    correo: "pedro@demo.local",
    password: "PruebaSegura!2026",
    rol: "CIUDADANO",
    area_id: "",
  };
  const docForm = {
    tipo_documento: "Oficio",
    remitente: "María Ciudadano Demo",
    identificacion: "10000003",
    asunto: "Oficio HTTP",
    descripcion: "Descripción de prueba HTTP",
    fecha_recepcion: "2026-10-09",
    area_id: "1",
    estado: "RECIBIDO",
  };
  const tramiteForm = {
    tipo_id: "1",
    solicitante: "María Ciudadano Demo",
    identificacion: "10000003",
    ciudadano_id: "3",
    documento_id: "1",
    asunto: "Trámite HTTP",
    descripcion: "Descripción de prueba HTTP",
    area_id: "1",
    estado: "PENDIENTE",
  };
  let tid;
  await test("Acceso anónimo redirige a login", async () =>
    assert.equal((await anon("/usuarios")).status, 302));
  await test("Login incorrecto y mensaje controlado", async () => {
    const p = await anon("/login");
    const r = await anon("/login", {
      csrf: csrf(p),
      correo: "admin@demo.local",
      password: "incorrecta",
    });
    assert.equal(r.status, 401);
    assert.match(r.text, /incorrectos/);
  });
  await test("Login correcto con los tres roles", async () => {
    await login(admin, "admin@demo.local");
    await login(staff, "funcionario@demo.local");
    await login(citizen, "ciudadano@demo.local");
  });
  await test("Todas las vistas principales se compilan en Tomcat", async () => {
    for (const route of [
      "/dashboard",
      "/usuarios",
      "/usuarios?accion=nuevo",
      "/usuarios?accion=editar&id=1",
      "/areas",
      "/areas?accion=nuevo",
      "/tipos",
      "/tipos?accion=editar&id=1",
      "/documentos",
      "/documentos?accion=nuevo",
      "/documentos?accion=editar&id=1",
      "/tramites",
      "/tramites?accion=nuevo",
      "/tramites?accion=editar&id=1",
      "/historial?id=1",
      "/derivaciones",
      "/derivaciones?id=1",
      "/reportes",
    ]) {
      const r = await admin(route);
      assert.equal(r.status, 200, route + " " + r.text.slice(-1000));
      assert.doesNotMatch(r.text, /JasperException|Stacktrace:/);
    }
  });
  await test("Permisos por URL y operaciones POST", async () => {
    assert.equal((await staff("/usuarios")).status, 403);
    assert.equal((await citizen("/documentos")).status, 403);
    const p = await citizen("/tramites");
    assert.equal(
      (await citizen("/tramites", { csrf: csrf(p), ...tramiteForm })).status,
      403,
    );
  });
  await test("Rechazo CSRF", async () =>
    assert.equal(
      (
        await admin("/areas", {
          nombre: "No debe crearse",
          descripcion: "x",
          csrf: "incorrecto",
        })
      ).status,
      403,
    ));
  await test("Registro y búsqueda de área", async () => {
    const p = await admin("/areas?accion=nuevo");
    assert.equal(
      (
        await admin("/areas", {
          csrf: csrf(p),
          nombre: "Área HTTP",
          descripcion: "Área de prueba",
        })
      ).status,
      302,
    );
    assert.match((await admin("/areas?q=Área HTTP")).text, /Área HTTP/);
  });
  await test("Edición, desactivación y reactivación de área conservan relaciones", async () => {
    let p = await admin("/areas?accion=editar&id=1");
    assert.equal(
      (
        await admin("/areas", {
          csrf: csrf(p),
          id: "1",
          nombre: "Mesa de Partes",
          descripcion: "Recepción y distribución actualizada",
        })
      ).status,
      302,
    );
    p = await admin("/areas");
    assert.equal(
      (
        await admin("/areas", {
          csrf: csrf(p),
          accion: "estado",
          id: "1",
          activo: "false",
        })
      ).status,
      302,
    );
    assert.equal((await admin("/historial?id=1")).status, 200);
    p = await admin("/areas");
    assert.equal(
      (
        await admin("/areas", {
          csrf: csrf(p),
          accion: "estado",
          id: "1",
          activo: "true",
        })
      ).status,
      302,
    );
  });
  await test("Catálogo de tipos extensible y selector dinámico", async () => {
    const p = await admin("/tipos?accion=nuevo");
    assert.equal(
      (
        await admin("/tipos", {
          csrf: csrf(p),
          nombre: "Licencia HTTP",
          descripcion: "Nuevo tipo desde catálogo",
        })
      ).status,
      302,
    );
    assert.match((await admin("/tramites?accion=nuevo")).text, /Licencia HTTP/);
  });
  await test("Registro de usuario y rechazo DNI/correo duplicados", async () => {
    let p = await admin("/usuarios?accion=nuevo");
    assert.equal(
      (await admin("/usuarios", { csrf: csrf(p), ...userForm })).status,
      302,
    );
    p = await admin("/usuarios?accion=nuevo");
    assert.equal(
      (
        await admin("/usuarios", {
          csrf: csrf(p),
          ...userForm,
          correo: "otro@demo.local",
        })
      ).status,
      409,
    );
    p = await admin("/usuarios?accion=nuevo");
    assert.equal(
      (
        await admin("/usuarios", {
          csrf: csrf(p),
          ...userForm,
          dni: "40000002",
        })
      ).status,
      409,
    );
  });
  await test("Edición de usuario conserva hash si contraseña vacía", async () => {
    const p = await admin("/usuarios?accion=editar&id=3");
    assert.equal(
      (
        await admin("/usuarios", {
          csrf: csrf(p),
          id: "3",
          nombres: "María",
          apellido_paterno: "Ciudadano",
          apellido_materno: "Demo",
          dni: "10000003",
          correo: "ciudadano@demo.local",
          password: "",
          rol: "CIUDADANO",
          area_id: "",
        })
      ).status,
      302,
    );
    await login(client("citizen2"), "ciudadano@demo.local");
  });
  await test("Registro de documento y nombres relacionados", async () => {
    const p = await staff("/documentos?accion=nuevo");
    assert.equal(
      (await staff("/documentos", { csrf: csrf(p), ...docForm })).status,
      302,
    );
    const list = await staff("/documentos?q=Oficio HTTP");
    assert.match(list.text, /Oficio HTTP/);
    assert.match(list.text, /Mesa de Partes/);
  });
  await test("Edición de documento y selector actual seleccionado", async () => {
    const p = await admin("/documentos?accion=editar&id=1");
    assert.match(p.text, /value="1" selected/);
    assert.equal(
      (
        await admin("/documentos", {
          csrf: csrf(p),
          id: "1",
          version: hidden(p, "version"),
          ...docForm,
          asunto: "Documento demo actualizado",
        })
      ).status,
      302,
    );
  });
  await test("IDs inexistentes y áreas ajenas rechazados", async () => {
    let p = await admin("/documentos?accion=nuevo");
    assert.equal(
      (
        await admin("/documentos", {
          csrf: csrf(p),
          ...docForm,
          area_id: "999999",
        })
      ).status,
      400,
    );
    p = await staff("/documentos?accion=nuevo");
    assert.equal(
      (await staff("/documentos", { csrf: csrf(p), ...docForm, area_id: "2" }))
        .status,
      403,
    );
    p = await admin("/tramites?accion=nuevo");
    assert.equal(
      (
        await admin("/tramites", {
          csrf: csrf(p),
          ...tramiteForm,
          tipo_id: "999999",
        })
      ).status,
      400,
    );
  });
  await test("Registro de trámite con documento y ciudadano existentes", async () => {
    const p = await staff("/tramites?accion=nuevo");
    const r = await staff("/tramites", { csrf: csrf(p), ...tramiteForm });
    assert.equal(r.status, 302, r.text.slice(-500));
    tid = r.location.match(/id=(\d+)/)[1];
    const history = await staff("/historial?id=" + tid);
    assert.match(history.text, /REGISTRO/);
    assert.match(history.text, /Documento relacionado/);
  });
  await test("Ciudadano consulta sus trámites y no los ajenos", async () => {
    assert.equal((await citizen("/historial?id=" + tid)).status, 200);
    const p = await admin("/tramites?accion=nuevo");
    const r = await admin("/tramites", {
      csrf: csrf(p),
      ...tramiteForm,
      ciudadano_id: "",
      asunto: "Trámite privado ajeno",
    });
    const other = r.location.match(/id=(\d+)/)[1];
    assert.equal((await citizen("/historial?id=" + other)).status, 403);
    assert.doesNotMatch(
      (await citizen("/tramites")).text,
      /Trámite privado ajeno/,
    );
  });
  await test("AJAX XML y escape seguro de caracteres", async () => {
    const r = await staff("/buscar-tramites?q=Trámite HTTP");
    assert.equal(r.status, 200);
    assert.match(r.type, /application\/xml/);
    assert.match(r.text, /<tramites>/);
    assert.match(r.text, /<id>/);
  });
  await test("Estado inválido y edición concurrente rechazados", async () => {
    const p = await admin("/tramites?accion=editar&id=" + tid);
    assert.equal(
      (
        await admin("/tramites", {
          csrf: csrf(p),
          id: tid,
          version: hidden(p, "version"),
          ...tramiteForm,
          estado: "CONCLUIDO",
        })
      ).status,
      400,
    );
    assert.equal(
      (
        await admin("/tramites", {
          csrf: csrf(p),
          id: tid,
          version: "99",
          ...tramiteForm,
          estado: "EN_PROCESO",
        })
      ).status,
      400,
    );
  });
  await test("Derivación inválida conserva expediente e historial", async () => {
    const p = await staff("/derivaciones?id=" + tid);
    assert.equal(
      (
        await staff("/derivaciones", {
          csrf: csrf(p),
          id: tid,
          version: hidden(p, "version"),
          area_destino_id: "1",
          observacion: "Mismo origen",
        })
      ).status,
      400,
    );
    assert.equal(
      (
        await staff("/derivaciones", {
          csrf: csrf(p),
          id: tid,
          version: hidden(p, "version"),
          area_destino_id: "999999",
          observacion: "Área inválida",
        })
      ).status,
      400,
    );
  });
  await test("Derivación actualiza área y agrega historial", async () => {
    const p = await staff("/derivaciones?id=" + tid);
    assert.equal(
      (
        await staff("/derivaciones", {
          csrf: csrf(p),
          id: tid,
          version: hidden(p, "version"),
          area_destino_id: "2",
          observacion: "Evaluación urbana del expediente",
        })
      ).status,
      302,
    );
    assert.equal((await staff("/historial?id=" + tid)).status, 403);
    const h = await admin("/historial?id=" + tid);
    assert.equal(h.status, 200);
    assert.match(h.text, /Desarrollo Urbano/);
    assert.match(h.text, /DERIVACION/);
    assert.match(h.text, /REGISTRO/);
  });
  await test("Atención y conclusión preservan eventos anteriores", async () => {
    for (const state of ["EN_PROCESO", "ATENDIDO", "CONCLUIDO"]) {
      const p = await admin("/tramites?accion=editar&id=" + tid);
      assert.equal(
        (
          await admin("/tramites", {
            csrf: csrf(p),
            id: tid,
            version: hidden(p, "version"),
            ...tramiteForm,
            area_id: "2",
            estado: state,
          })
        ).status,
        302,
      );
    }
    const h = await citizen("/historial?id=" + tid);
    assert.match(h.text, /CONCLUIDO/);
    assert.match(h.text, /DERIVACION/);
    assert.match(h.text, /CAMBIO ESTADO/);
    assert.equal(
      (await admin("/tramites?accion=editar&id=" + tid)).status,
      400,
    );
  });
  await test("Dashboard y filtros de reportes con datos reales", async () => {
    assert.match((await admin("/dashboard")).text, /Trámites recientes/);
    const r = await admin(
      "/reportes?estado=CONCLUIDO&area=2&tipo=1&desde=2026-01-01&hasta=2026-12-31",
    );
    assert.equal(r.status, 200);
    assert.match(r.text, /Trámite HTTP/);
    const empty = await admin("/reportes?desde=2000-01-01&hasta=2000-01-02");
    assert.match(empty.text, /No hay resultados/);
  });
  await test("Exportación CSV aplica permisos y filtros", async () => {
    const r = await citizen("/reportes?exportar=csv");
    assert.equal(r.status, 200);
    assert.match(r.type, /text\/csv/);
    assert.match(r.text, /Trámite HTTP/);
    assert.doesNotMatch(r.text, /Trámite privado ajeno/);
  });
  await test("Página no encontrada y errores sin trazas", async () => {
    const r = await admin("/ruta-inexistente");
    assert.equal(r.status, 404);
    assert.match(r.text, /Página no encontrada/);
    assert.doesNotMatch(r.text, /Exception|Stacktrace:/);
  });
  await test("Cerrar sesión invalida acceso privado", async () => {
    const p = await citizen("/dashboard");
    assert.equal((await citizen("/logout", { csrf: csrf(p) })).status, 302);
    assert.equal((await citizen("/dashboard")).status, 302);
  });
  return results;
}
module.exports = { run };
if (require.main === module) {
  if (process.env.ALLOW_TEST_MUTATIONS !== "true")
    throw Error(
      "Establezca ALLOW_TEST_MUTATIONS=true solo con una base desechable.",
    );
  run(process.env.TEST_BASE_URL || "http://localhost:8080/tramite")
    .then((r) => {
      fs.writeFileSync("http-results.json", JSON.stringify(r, null, 2));
      process.exitCode = r.some((x) => x.status === "FAIL") ? 1 : 0;
    })
    .catch((e) => {
      console.error(e);
      process.exitCode = 1;
    });
}
