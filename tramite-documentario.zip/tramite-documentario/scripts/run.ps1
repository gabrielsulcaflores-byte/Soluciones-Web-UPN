param(
    [string]$TomcatHome = $env:TOMCAT_HOME,
    [string]$Config = $env:TRAMITE_CONFIG,
    [int]$Port = 8080,
    [switch]$SkipBuild
)
$ErrorActionPreference = 'Stop'
$projectRoot = Split-Path $PSScriptRoot -Parent
if (-not $TomcatHome) { throw 'Indique -TomcatHome con la carpeta de Tomcat 11 o configure TOMCAT_HOME.' }
$TomcatHome = (Resolve-Path -LiteralPath $TomcatHome).Path
if (-not (Test-Path -LiteralPath (Join-Path $TomcatHome 'lib\servlet-api.jar'))) { throw 'La carpeta de Tomcat no es válida.' }
if ($Port -lt 1024 -or $Port -gt 65535) { throw 'Seleccione un puerto entre 1024 y 65535.' }
if (-not $Config -and -not $env:DB_PASSWORD) { $Config = Join-Path $projectRoot 'config\database.properties' }
if ($Config) { $Config = (Resolve-Path -LiteralPath $Config).Path }
Push-Location $projectRoot
try {
    if (-not $SkipBuild) {
        & "$projectRoot\mvnw.ps1" '-B' '-ntp' 'package'
        if ($LASTEXITCODE -ne 0) { throw 'La compilación falló.' }
    }
    $webRoot = Join-Path $projectRoot 'target\tramite'
    if (-not (Test-Path -LiteralPath $webRoot)) { throw 'Compile primero el proyecto.' }
    $runtimeDir = Join-Path $projectRoot '.runtime\tomcat'
    foreach ($folder in @('conf','logs','temp','work','webapps','conf\Catalina\localhost')) {
        New-Item -ItemType Directory -Force (Join-Path $runtimeDir $folder) | Out-Null
    }
    foreach ($file in @('web.xml','catalina.properties','logging.properties')) {
        Copy-Item -LiteralPath (Join-Path $TomcatHome "conf\$file") -Destination (Join-Path $runtimeDir "conf\$file") -Force
    }
    $server = @"
<?xml version="1.0" encoding="UTF-8"?>
<Server port="-1"><Service name="Catalina">
<Connector address="127.0.0.1" port="$Port" protocol="HTTP/1.1" connectionTimeout="20000" URIEncoding="UTF-8" />
<Engine name="Catalina" defaultHost="localhost"><Host name="localhost" appBase="webapps" unpackWARs="false" autoDeploy="false" /></Engine>
</Service></Server>
"@
    Set-Content -LiteralPath (Join-Path $runtimeDir 'conf\server.xml') -Value $server -Encoding UTF8
    $escapedRoot = [System.Security.SecurityElement]::Escape($webRoot)
    Set-Content -LiteralPath (Join-Path $runtimeDir 'conf\Catalina\localhost\tramite.xml') -Value "<Context docBase=`"$escapedRoot`" reloadable=`"false`"><CookieProcessor sameSiteCookies=`"lax`" /></Context>" -Encoding UTF8
    $classPath = "$(Join-Path $TomcatHome 'bin\bootstrap.jar');$(Join-Path $TomcatHome 'bin\tomcat-juli.jar')"
    $javaArgs = @("-Dcatalina.home=$TomcatHome", "-Dcatalina.base=$runtimeDir", '-Dfile.encoding=UTF-8')
    if ($Config) { $javaArgs += "-Dtramite.config=$Config" }
    Write-Host "Abrir http://localhost:$Port/tramite/ — Ctrl+C para detener."
    & java @javaArgs '-cp' $classPath 'org.apache.catalina.startup.Bootstrap' 'start'
} finally { Pop-Location }
