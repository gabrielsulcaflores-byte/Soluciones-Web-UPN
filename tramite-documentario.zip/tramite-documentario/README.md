# Sistema web de trámite documentario · Los Olivos

Proyecto académico del curso Soluciones Web. Organiza documentos y expedientes, deriva trámites entre áreas y conserva su historial. Usa MVC tradicional: JSP → Servlet → servicio/DAO → JDBC → MySQL.

## Entorno compatible

| Componente            | Versión                                        |
| --------------------- | ---------------------------------------------- |
| Java JDK              | 17                                             |
| Apache Tomcat         | 11.0.x                                         |
| Jakarta Servlet / JSP | 6.1 / Pages 4.0                                |
| MySQL                 | 8.0.16+; esquema comprobado en 9.7             |
| Maven                 | 3.9.x; incluido un lanzador que descarga 3.9.9 |
| Bootstrap             | 5.3.3, archivos locales                        |
| Connector/J           | 9.2.0                                          |
| JSTL                  | API 3.0.2, implementación 3.0.1                |

Todos los imports de Servlet usan `jakarta.servlet`. Tomcat 9 y versiones de Java anteriores a 17 no son compatibles. La compatibilidad de Tomcat se detalla en [Apache](https://tomcat.apache.org/migration-11.0.html).

## Abrir y ejecutar en Visual Studio Code (Windows)

1. Extrae el ZIP y abre **la carpeta que contiene `pom.xml`** en VS Code mediante Archivo → Abrir carpeta. Acepta las extensiones recomendadas: Extension Pack for Java, Maven for Java y Community Server Connectors.
2. Comprueba `java -version`. Debe indicar JDK 17. Si es necesario, define `JAVA_HOME` con la carpeta del JDK y agrega su `bin` al PATH. Instala Tomcat 11 y MySQL si aún no están disponibles.
3. Inicia el servicio de MySQL desde su herramienta de administración. Abre MySQL Workbench con tu cuenta administradora y ejecuta **una sola vez** `database/tramite_documentario.sql` usando el botón de ejecutar todo el script. No requiere ni elimina una base existente con otro nombre. Si ya importaste esta misma base, no repitas la creación de tablas: usa una base nueva para pruebas o conserva la instalada.
4. Ejecuta `database/usuario_aplicacion.sql.example` después de reemplazar su contraseña. Crea una cuenta MySQL con permisos sobre esta base. Esa contraseña corresponde a JDBC, no al inicio de sesión web.
5. Copia `config/database.properties.example` a `config/database.properties`. Coloca el puerto, usuario y contraseña reales de MySQL. Este archivo está excluido de Git. También puedes guardarlo fuera del proyecto y pasar `-Config` a los scripts.
6. Compila desde la terminal de VS Code:

```powershell
.\mvnw.cmd -B -ntp clean verify
```

El lanzador usa el Maven instalado o descarga Maven desde Maven Central, verificando SHA512. La primera compilación necesita Internet para Maven y dependencias. Java, Tomcat y MySQL deben instalarse por separado. Bootstrap ya está incluido, por lo que la interfaz funciona sin CDN.

7. Comprueba la conexión JDBC:

```powershell
powershell -ExecutionPolicy Bypass -File scripts/check-db.ps1
```

Si no indica conexión correcta, revisa la configuración antes de continuar. No se proporcionan ni se adivinan las credenciales de tu instalación de MySQL.

8. Elige una de estas opciones para las cuentas de la web:
   - **Demostración local:** importa `database/datos_demo.sql` una sola vez después del esquema. Incluye tres cuentas, un documento y un trámite. Los hashes se generaron con PBKDF2; no contiene contraseñas en texto plano en los registros SQL.
   - **Base sin demostración:** crea tu administrador con `powershell -ExecutionPolicy Bypass -File scripts/create-admin.ps1`. Solicita nombres, DNI, correo y una contraseña de 12 a 128 caracteres que no se muestra en pantalla.
9. Inicia Tomcat:

```powershell
powershell -ExecutionPolicy Bypass -File scripts/run.ps1 -TomcatHome "C:\Program Files\apache-tomcat-11.0.25"
```

Abre [http://localhost:8080/tramite/](http://localhost:8080/tramite/). La terminal debe permanecer abierta. Detén con Ctrl+C. El script utiliza una instancia de Tomcat bajo `.runtime/tomcat` y no modifica la instalación original. Si 8080 está ocupado, añade `-Port 8081` y abre esa dirección. Para una configuración externa, añade `-Config "C:\ruta\database.properties"`.

La misma aplicación se puede desplegar copiando `target/tramite.war` al directorio `webapps` de Tomcat 11. En ese caso, configura `TRAMITE_CONFIG` como ruta absoluta o las variables `DB_URL`, `DB_USER`, `DB_PASSWORD` **antes de arrancar Tomcat**. La primera opción resulta más sencilla en VS Code.

## Credenciales exclusivas de demostración

Disponibles solamente después de importar `database/datos_demo.sql`:

| Rol           | Correo                 | Contraseña      |
| ------------- | ---------------------- | --------------- |
| Administrador | admin@demo.local       | DemoOlivos!2026 |
| Funcionario   | funcionario@demo.local | DemoOlivos!2026 |
| Ciudadano     | ciudadano@demo.local   | DemoOlivos!2026 |

El funcionario está asignado a Mesa de Partes. El ciudadano tiene el DNI ficticio 10000003 y un trámite vinculado. Son cuentas académicas públicas; para datos reales utiliza el esquema sin `datos_demo.sql` y crea tu propia cuenta.

## Módulos y reglas

| Módulo           | Operaciones                                                                                                                              |
| ---------------- | ---------------------------------------------------------------------------------------------------------------------------------------- |
| Usuarios         | Registro, consulta, búsqueda, edición, contraseña opcional en edición, activación y desactivación. DNI/correo únicos.                    |
| Áreas            | Registro, consulta, búsqueda, edición y cambio de disponibilidad. Los registros históricos conservan la relación.                        |
| Tipos de trámite | Catálogo editable. Solicitud, Queja y Permiso iniciales; añadir Licencia no requiere cambiar Java o JSP.                                 |
| Documentos       | Registro, consulta, filtros y edición. Código generado, estado y área existente. La anulación conserva el documento y cierra la edición. |
| Trámites         | Registro, consulta, filtros, edición, estado y seguimiento. Tipo/área de MySQL, documento y cuenta ciudadana opcionales.                 |
| Derivaciones     | Búsqueda AJAX/XML, elección del expediente, destino activo y motivo. Transacción con actualización de área e historial.                  |
| Historial        | Detalle y eventos cronológicos; muestra responsables y nombres de áreas. No ofrece edición ni borrado.                                   |
| Dashboard        | Totales, distribución por estado/área y registros recientes, consultados en MySQL según permisos.                                        |
| Reportes         | Fechas, estado, área y tipo. Consulta, impresión y exportación CSV con los mismos permisos.                                              |

Los listados muestran hasta 200 registros; la búsqueda dinámica hasta 20; los reportes hasta 10 000. Para grandes volúmenes, el siguiente paso sería incorporar paginación. No se incluye carga de archivos adjuntos porque no está requerida en el alcance entregado.

El catálogo auxiliar de tipos de documento es una lista fija de Solicitud, Oficio, Carta, Informe, Memorando y Otro, separada del catálogo dinámico de tipos de trámite.

### Flujo de estados de trámite

```text
PENDIENTE → EN_PROCESO → ATENDIDO → CONCLUIDO
     └── derivación → DERIVADO → EN_PROCESO
```

Una derivación desde pendiente, en proceso o derivado pone el expediente en DERIVADO y cambia el área. Atendido/concluido no se deriva; concluido no se edita. No se permite saltar de pendiente a concluido. La edición de un trámite no cambia el área: se realiza mediante Derivaciones. Todas las ediciones agregan un evento; nunca sobrescriben los anteriores. La columna `version` detecta formularios desactualizados.

### Permisos

| Acción                            | Administrador         | Funcionario    | Ciudadano                                 |
| --------------------------------- | --------------------- | -------------- | ----------------------------------------- |
| Administrar usuarios/áreas/tipos  | Sí                    | No             | No                                        |
| Registrar documentos/trámites     | Cualquier área activa | Su área activa | No                                        |
| Consultar/editar documentos       | Todos                 | Su área actual | No                                        |
| Consultar/editar/derivar trámites | Todos                 | Su área actual | Solo consultar los vinculados a su cuenta |
| Dashboard/reportes/CSV            | Todos                 | Su área actual | Sus trámites                              |

Cuando un funcionario deriva a otra área, pierde el acceso a ese expediente. Los funcionarios del destino lo reciben. El administrador puede seguir consultándolo. Para permitir consulta ciudadana, el funcionario debe elegir una cuenta ciudadana existente y el DNI del solicitante debe coincidir con la cuenta. Se evita revelar expedientes basándose únicamente en un DNI proporcionado por el visitante.

Las restricciones se verifican en `SecurityFilter` y los servicios, incluyendo acceso directo por URL. La sesión vuelve a consultar usuario y estado en cada solicitud privada: desactivar una cuenta revoca su acceso. No se permite desactivar la propia cuenta administradora ni dejar el sistema sin un administrador activo.

## Estructura

```text
tramite-documentario/
├── pom.xml, mvnw.cmd, mvnw.ps1
├── .vscode/                     Recomendaciones y tareas de VS Code
├── config/                      Ejemplo de configuración externa
├── database/                    Esquema, catálogos y datos demo separados
├── scripts/                     Arranque, diagnóstico y pruebas HTTP
├── docs/                        Diseño, SOLID y resultados de pruebas
└── src/
    ├── main/java/pe/edu/solucionesweb/tramite/
    │   ├── model/               JavaBeans y datos para presentación
    │   ├── controller/          Servlets por módulo
    │   ├── dao/                 JDBC y contratos específicos
    │   ├── service/             Permisos, relaciones y transacciones
    │   ├── util/                Conexión, validación, SQL y contraseñas
    │   └── filter/              Sesión, permisos y CSRF
    ├── main/webapp/
    │   ├── assets/              Bootstrap, CSS, JS y emblema académico
    │   └── WEB-INF/views/       JSP protegidas, formularios y listados
    └── test/java/               JUnit y pruebas MySQL optativas
```

Las JSP no contienen SQL ni ejecutan lógica de negocio. Los DAO devuelven JavaBeans para entidades y filas de consulta para tablas y reportes. Se reutiliza el formulario/listado JSP con metadatos de presentación, manteniendo un Servlet y DAO por mantenimiento.

## Modelo relacional, seguridad y SOLID

Ver [DISEÑO.md](docs/DISEÑO.md) y [SOLID.md](docs/SOLID.md). Las siete tablas tienen 14 claves foráneas, índices y restricciones. Las dos relaciones de área de una derivación representan origen y destino; `tramites.area_id` es el responsable actual. `ciudadano_id` identifica a quien puede consultar, `usuario_id` a quien registró, y `documento_id` al documento asociado.

Consultas preparadas, validaciones del servidor, escape de salida con JSTL, CSRF, sesiones por cookie HttpOnly, cabeceras de seguridad, PBKDF2-HMAC-SHA256 con sal y 600 000 iteraciones, transacciones y control de versiones. Cinco intentos fallidos limitan la sesión de acceso por un minuto; es una medida académica, no un servicio de protección distribuido.

El servidor de los scripts escucha únicamente en el equipo local. Para un despliegue externo se debe configurar HTTPS, cookies Secure, gestión de secretos, copias de seguridad, permisos de red y protección más robusta de intentos de acceso.

## Pruebas y estado de verificación

Consulta [PRUEBAS.md](docs/PRUEBAS.md). Se ejecutaron cinco pruebas JUnit, compilación Java/WAR, compilación de todas las JSP con Jasper y creación real del esquema/datos en MySQL, además de verificaciones SQL de integridad, edición, derivación e historial. La conexión JDBC y la suite HTTP están preparadas, pero **no quedaron ejecutadas satisfactoriamente** en este entorno porque las conexiones locales se rechazan con acceso denegado. No se declara la aceptación funcional completa hasta ejecutar esas pruebas en una terminal con acceso local a MySQL/Tomcat.

Para probar las transacciones sobre **una base desechable**, con los datos demo importados y sin cambios previos:

```powershell
$env:TRAMITE_CONFIG = (Resolve-Path config/database.properties).Path
$env:RUN_MYSQL_TESTS = 'true'
.\mvnw.cmd -B -ntp test
Remove-Item Env:RUN_MYSQL_TESTS
```

Para las 25 verificaciones HTTP prepara **una base desechable recién importada** y arranca Tomcat sobre esa base. En una segunda terminal con Node.js 20+:

```powershell
$env:ALLOW_TEST_MUTATIONS = 'true'
$env:TEST_BASE_URL = 'http://localhost:8080/tramite'
node scripts/test-http.cjs
```

La suite crea/edita/deriva registros de prueba y escribe `http-results.json`. No la ejecutes sobre información real. Una ejecución nueva necesita una base demo nueva porque incluye validaciones de duplicados.

## Solución de problemas

- **Java no se encuentra:** instala JDK 17 y verifica `JAVA_HOME`/PATH; reinicia la terminal.
- **Tomcat no se encuentra:** especifica la carpeta raíz con `-TomcatHome`, no `bin`.
- **Conexión MySQL falla:** revisa que el servicio esté iniciado, puerto (habitualmente 3306), usuario y contraseña. Ejecuta `scripts/check-db.ps1`.
- **Acceso denegado de MySQL:** usa la cuenta creada con el script de permisos, comprueba host y contraseña. No copies las credenciales de la web al archivo JDBC.
- **Tablas inexistentes:** ejecuta todo `tramite_documentario.sql`, no solo la primera sentencia.
- **No puedo iniciar sesión:** importa datos demo o crea un administrador. Verifica que la cuenta esté activa.
- **Puerto ocupado:** cambia `-Port` al arrancar.
- **Cambios no aparecen:** detén Tomcat y arranca de nuevo para recompilar; no uses `-SkipBuild` tras modificar fuentes.

El emblema y el diseño representan una plataforma académica; no se presenta como un portal oficial de la municipalidad.
