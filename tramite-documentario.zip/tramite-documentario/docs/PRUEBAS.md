# Pruebas y resultados

Fecha de preparación y ejecución: 9 de octubre de 2026, America/Lima.

## Ejecutado

| Verificación                                                          | Resultado real                                                                                                   |
| --------------------------------------------------------------------- | ---------------------------------------------------------------------------------------------------------------- |
| Maven `clean verify`, JDK 17                                          | Correcto; compilación del código y empaquetado WAR.                                                              |
| Hash de contraseña, sal distinta, contraseña incorrecta/hash inválido | JUnit correcto.                                                                                                  |
| DNI, identificación y correo                                          | JUnit correcto.                                                                                                  |
| Secuencia de estados y rechazo de saltos/reapertura                   | JUnit correcto.                                                                                                  |
| Permisos por propietario/área en reglas Java                          | JUnit correcto.                                                                                                  |
| Escape CSV y protección de fórmulas                                   | JUnit correcto.                                                                                                  |
| JSP con Apache Jasper de Tomcat 11                                    | Generación/compilación finalizada con 0 errores.                                                                 |
| Esquema y datos demo en MySQL 9.7                                     | Correcto. 7 tablas, 14 claves foráneas, 4 áreas, 3 tipos, 3 usuarios, 1 documento, 1 trámite y 1 evento inicial. |

La creación SQL se ejecutó mediante el mecanismo `--init-file` de una instancia desechable de MySQL, sin conexión de red. Los resultados se verificaron mediante un archivo producido por una consulta real a las tablas y a `information_schema`. Esto verifica el SQL, pero no demuestra que la conexión JDBC ni las operaciones HTTP funcionen.

También se ejecutaron verificaciones directas en MySQL: rechazo de área, DNI y correo duplicados (error 1062), tipo inexistente por clave foránea (1452) e identificación inválida por CHECK (3819). Se comprobaron inserción/edición de documento, registro y derivación SQL de un trámite, dos eventos conservados, rollback sin filas restantes y consulta histórica de un área desactivada. Son pruebas del esquema y sentencias SQL, no una prueba ejecutada de los DAO/Servlets.

Las evidencias resumidas están en `evidencia-sql.txt` y `evidencia-junit.txt`.

## Pendiente por una limitación concreta del entorno

Las conexiones TCP locales devolvieron acceso denegado (`EACCES`); el canal de MySQL por named pipe también devolvió acceso denegado (error 5). La navegación al servidor local no pudo completarse. No se modificaron el firewall ni las protecciones del equipo.

Las tres pruebas `MySqlIntegrationTest` quedaron **omitidas**, no aprobadas. Comprueban:

1. Rollback del registro si falla el historial.
2. Rollback de una derivación si falla el evento.
3. Rechazo de clave foránea inexistente y nombre de área duplicado.

La suite `scripts/test-http.cjs` contiene verificaciones de login, roles, CSRF, los cinco módulos, selectores, relaciones, duplicados, historial, derivación, estados, concurrencia, reportes, CSV, errores y logout. Queda pendiente ejecutarla satisfactoriamente. No se incluyen resultados PASS inventados ni se afirma que se completó la revisión visual/manual de las pantallas.

## Reproducción

Sin MySQL: `.\mvnw.cmd -B -ntp clean verify` ejecuta cinco pruebas unitarias y omite las tres optativas de integración.

Con MySQL: siga el README y use una base desechable demo recién creada. Configure `TRAMITE_CONFIG` y `RUN_MYSQL_TESTS=true`; ejecute Maven `test`. Luego arranque Tomcat con esa misma configuración y ejecute la suite HTTP con Node.js 20+, `ALLOW_TEST_MUTATIONS=true` y `TEST_BASE_URL`.

## Revisión manual antes de la aceptación final

- Ingresar con los tres roles y verificar menú/acceso directo.
- Registrar, buscar y editar los cinco mantenimientos.
- Verificar DNI/correo/nombres repetidos y mensajes.
- Desactivar catálogos usados; confirmar que se conserva el historial y no aparecen en registros nuevos.
- Registrar un documento y trámite seleccionando IDs existentes; editar y confirmar valores seleccionados.
- Registrar un trámite sin ciudadano, después uno vinculado y comprobar privacidad.
- Derivar desde Mesa de Partes a Desarrollo Urbano; comprobar área, estado, historial y pérdida de acceso del funcionario de origen.
- Hacer el ciclo en proceso → atendido → concluido y comprobar que todos los eventos permanecen.
- Consultar reportes, exportar CSV e imprimir desde el navegador.
- Probar AJAX con tildes y caracteres especiales, sin resultados, con sesión vencida y con error de red.
- Revisar pantalla móvil, mensajes de error/acceso denegado y cierre de sesión.

Hasta completar esas verificaciones, el estado es: **implementado y compilado; aceptación funcional de punta a punta pendiente**.
