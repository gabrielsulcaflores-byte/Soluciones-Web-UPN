# Evidencia honesta de SOLID

| Principio | Clases y ejemplo                                                                                                                                                                                                                                                                  | Problema que evita                                                       |
| --------- | --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | ------------------------------------------------------------------------ |
| SRP       | `Tramite` transporta datos; `TramiteServlet` interpreta formularios; `TramiteDAO` contiene SQL; `TramiteService` coordina transacciones; JSP presenta datos.                                                                                                                      | Mezclar SQL, HTML y negocio en una sola clase o JSP.                     |
| OCP       | `tipos_tramite`, `TipoTramiteDAO.opciones()` y el selector en `TramiteServlet`. Añadir Licencia en el mantenimiento hace que aparezca sin editar Java/JSP.                                                                                                                        | Condiciones repetidas por cada tipo de trámite.                          |
| LSP       | `TramiteDAO` cumple `TramiteRepository` y `HistorialDAO` cumple `EventRepository`. Los servicios utilizan esos contratos sin exigir una implementación específica. Las implementaciones de prueba conservan firmas y lanzan SQLException dentro del contrato.                     | Que una sustitución imponga operaciones o restricciones incompatibles.   |
| ISP       | `EventRepository` solo exige `registrar`; `TramiteRepository` tiene cuatro operaciones necesarias para el servicio transaccional; `ConnectionProvider` solo abre conexiones.                                                                                                      | Interfaces universales que obligan a implementar operaciones sin uso.    |
| DIP       | Constructor de `TramiteService(ConnectionProvider, TramiteRepository, EventRepository, DerivacionDAO)`. El servicio recibe los contratos de conexión, expediente e historial. `MySqlIntegrationTest` sustituye el registro de eventos para simular un fallo y comprobar rollback. | Acoplar toda la lógica de trámite al modo de construir una conexión/DAO. |

## Ejemplos para sustentar

```java
// DAO implementa contrato específico (LSP/ISP).
public class HistorialDAO implements EventRepository {
  public void registrar(Connection c, long tramite, long usuario,
                        String accion, String descripcion) throws SQLException {
    // INSERT preparado, sobre la conexión de la transacción.
  }
}

// El servicio recibe abstracciones (DIP), sin un contenedor de inyección.
public TramiteService(ConnectionProvider c, TramiteRepository t,
                      EventRepository e, DerivacionDAO d) {
  connections = c;
  tramites = t;
  events = e;
  derivaciones = d;
}
```

La inversión de dependencias es proporcional: `DerivacionDAO` y las validaciones de relaciones siguen siendo detalles JDBC concretos. No se afirma que toda la infraestructura sea intercambiable. Ampliar esa separación se justificaría si el curso exigiera otro almacenamiento o pruebas unitarias de negocio independientes de SQL.

No se creó una jerarquía artificial de entidades para aparentar LSP. Las entidades no necesitan herencia. En la jerarquía natural de Servlets, todos los controladores son `HttpServlet` a través de `BaseServlet`; usan las operaciones GET/POST del contrato HTTP. Es una organización técnica, no una demostración de herencia de dominio.

Las pruebas de sustitución de repositorios y rollback están escritas para MySQL y pendientes de ejecución por la restricción de conexiones locales del entorno de generación. Las pruebas ejecutadas y sus límites se detallan en PRUEBAS.md.
