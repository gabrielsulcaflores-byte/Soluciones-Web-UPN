# Diagnóstico y diseño

La carpeta inicial contenía `work/` y `outputs/`, sin fuentes, `pom.xml`, frontend Angular, Spring Boot ni repositorio Git. No se reemplazó un proyecto previo. La implementación nueva está en una carpeta independiente, lista para abrirse en VS Code.

## Relaciones

```mermaid
erDiagram
    areas ||--o{ usuarios : asigna_funcionarios
    areas ||--o{ documentos : recibe
    areas ||--o{ tramites : responsable_actual
    tipos_tramite ||--o{ tramites : clasifica
    usuarios ||--o{ documentos : registra
    usuarios ||--o{ tramites : registra
    usuarios o|--o{ tramites : consulta_como_ciudadano
    documentos o|--o{ tramites : acompana
    tramites ||--o{ derivaciones : se_deriva
    areas ||--o{ derivaciones : origen
    areas ||--o{ derivaciones : destino
    usuarios ||--o{ derivaciones : efectua
    tramites ||--o{ historial_tramites : conserva
    usuarios ||--o{ historial_tramites : responsable
```

No se necesita duplicar áreas, tipos ni usuarios al registrar un expediente. Los `select` muestran nombres y envían IDs. El servidor valida existencia/actividad y permisos. Una relación previamente seleccionada e inactiva puede conservarse durante una edición; no se admite como una asignación nueva. Los catálogos desactivados permanecen visibles en el historial.

Los DNI y correos de usuarios, nombres de catálogos y códigos de documentos/trámites son únicos. Las claves foráneas restringen eliminación. Los códigos se generan con prefijo y 16 caracteres de UUID; la restricción UNIQUE evita cualquier duplicado accidental.

## Decisiones de alcance

- El ciudadano consulta expedientes vinculados explícitamente a su cuenta; no registra ni edita trámites en este alcance académico.
- El funcionario trabaja en un área asignada. Para derivar debe tener acceso al área actual; el destino puede ser cualquier área activa distinta.
- No hay eliminación física desde la interfaz. Usuarios/áreas/tipos pueden reactivarse. Los documentos anulados conservan su información y no se editan.
- El tipo de documento es una lista auxiliar fija; el tipo de trámite es un catálogo editable almacenado en MySQL.
- El historial guarda cualquier edición y los cambios de estado o área. Una derivación incluye nombres de origen/destino y motivo en la descripción del evento.
- Los eventos del historial y derivaciones no tienen acciones de modificación o borrado en la aplicación.
- Las fechas de negocio usan America/Lima; recepción es DATE y los eventos son DATETIME. Cada conexión fija `time_zone=-05:00` para que `CURRENT_TIMESTAMP` respete la hora del proyecto sin requerir tablas de zonas horarias. Connector/J se configura con `connectionTimeZone=America/Lima`.
- JSP comunes evitan repetir presentación, pero cada mantenimiento mantiene su propio Servlet y DAO. No se incorporan frameworks de negocio.

## Transacción de derivación

1. Abrir conexión y desactivar autocommit.
2. Bloquear trámite con `SELECT ... FOR UPDATE`.
3. Comprobar rol, área actual, versión del formulario, estado y destino activo.
4. Insertar derivación.
5. Actualizar área, estado y versión.
6. Insertar historial.
7. Confirmar con commit; cualquier excepción ejecuta rollback.

Registro y edición de trámites también guardan expediente e historial en la misma conexión. La edición administrativa de usuarios se serializa sobre los administradores activos para preservar al menos uno y proteger cambios concurrentes.
